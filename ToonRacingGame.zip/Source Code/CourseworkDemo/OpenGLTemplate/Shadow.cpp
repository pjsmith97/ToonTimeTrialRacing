#include "Shadow.h"
#define _USE_MATH_DEFINES
#include <math.h>

Shadow::Shadow()
{

}

Shadow::~Shadow()
{
	Release();
}

void Shadow::CreateShadow() {
	GLfloat border[] = { 1.0f,0.0f,0.0f,0.0f }; 
	//The shadowmap texture 
	GLuint depthTex; 
	glGenTextures(1,&depthTex); 
	glBindTexture(GL_TEXTURE_2D,depthTex); 
	glTexStorage2D(GL_TEXTURE_2D, 1, GL_DEPTH_COMPONENT24, shadowMapWidth, shadowMapHeight); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_NEAREST); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_NEAREST); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER); 
	glTexParameterfv(GL_TEXTURE_2D,GL_TEXTURE_BORDER_COLOR, border); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE); 
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_COMPARE_FUNC, GL_LESS); 
	//Assign the shadow map to texture unit 0 
	glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D,depthTex); 
	//Create and set up the FBO 
	glGenFramebuffers(1,&m_fboShadow); 
	glBindFramebuffer(GL_FRAMEBUFFER, m_fboShadow); 
	glFramebufferTexture2D(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D,depthTex,0); 
	GLenum drawBuffers[]={GL_NONE}; glDrawBuffers(1,drawBuffers); 
	// Revert to the default framebuffer for now 
	glBindFramebuffer(GL_FRAMEBUFFER,0);
}

void Shadow::Release() {
	//glDeleteVertexArrays(1, &m_fboShadow);
	glDeleteFramebuffers(1, &m_fboShadow);
	m_vboShadow.Release();
}