#include "Roof.h"
#include <iostream>
CRoof::CRoof()
{}
CRoof::~CRoof()
{
	Release();
}
void CRoof::Create(string filename)
{
	m_texture.Load(filename);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_S, GL_REPEAT);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_T, GL_REPEAT);
	glGenVertexArrays(1, &m_vao);
	glBindVertexArray(m_vao);
	m_vbo.Create();
	m_vbo.Bind();
	// Write the code to add interleaved vertex attributes to the VBO
	std::vector<glm::vec3> p_vec = { glm::vec3(-1.2, 0.8, 1.2) , glm::vec3(1.2, 0.8, 1.2) , glm::vec3(-0.5, 1.5, 0.5) , glm::vec3(0.5, 1.5, 0.5) , //done
		glm::vec3(1.2, 0.8, 1.2) , glm::vec3(1.2, 0.8, -1.2) ,  glm::vec3(0.5, 1.5, 0.5) , glm::vec3(0.5, 1.5, -0.5) , //done
		glm::vec3(-1.2, 0.8, -1.2), glm::vec3(-1.2, 0.8, 1.2), glm::vec3(-0.5, 1.5, -0.5), glm::vec3(-0.5, 1.5, 0.5), //done
		glm::vec3(-0.5, 1.5, 0.5) , glm::vec3(0.5, 1.5, 0.5) , glm::vec3(-0.5, 1.5, -0.5) , glm::vec3(0.5, 1.5, -0.5) , //done
		glm::vec3(1.2, 0.8, -1.2) , glm::vec3(-1.2, 0.8, -1.2) , glm::vec3(0.5, 1.5, -0.5) , glm::vec3(-0.5, 1.5, -0.5) ,
		glm::vec3(-1.2, 0.8, -1.2), glm::vec3(1.2, 0.8, -1.2) , glm::vec3(-1.2, 0.8, 1.2), glm::vec3(1.2, 0.8, 1.2)
	}; // done

	std::vector<glm::vec2> s_vec = { glm::vec2(0, 0) , glm::vec2(1, 0) , glm::vec2(0, 1) , glm::vec2(1, 1) };

	std::vector<glm::vec3> n_vec = 
		{ glm::normalize(glm::cross((glm::vec3(1.2, 0.8, 1.2) - glm::vec3(-1.2, 0.8, 1.2)), (glm::vec3(-0.5, 1.5, 0.5) - glm::vec3(-1.2, 0.8, 1.2)))), 
		glm::normalize(glm::cross((glm::vec3(1.2, 0.8, -1.2) - glm::vec3(1.2, 0.8, 1.2)), (glm::vec3(0.5, 1.5, 0.5) - glm::vec3(1.2, 0.8, 1.2)))),
		glm::normalize(glm::cross((glm::vec3(-1.2, 0.8, 1.2) - glm::vec3(-1.2, 0.8, -1.2)), (glm::vec3(-0.5, 1.5, -0.5) - glm::vec3(-1.2, 0.8, -1.2)))),
		glm::normalize(glm::cross((glm::vec3(0.5, 1.5, 0.5) - glm::vec3(-0.5, 1.5, 0.5)), (glm::vec3(-0.5, 1.5, -0.5) - glm::vec3(-0.5, 1.5, 0.5)))),
		glm::normalize(glm::cross((glm::vec3(-1.2, 0.8, -1.2) - glm::vec3(1.2, 0.8, -1.2)), (glm::vec3(0.5, 1.5, -0.5) - glm::vec3(1.2, 0.8, -1.2)))),
		glm::normalize(glm::cross((glm::vec3(1.2, 0.8, -1.2) - glm::vec3(-1.2, 0.8, -1.2)), (glm::vec3(-1.2, 0.8, 1.2) - glm::vec3(-1.2, 0.8, -1.2))))
		};

	/*for (int n = 0; n < n_vec.size(); n++) {
		std::cout << "(" << &n_vec[n].x << ", " << &n_vec[n].y << ", " << &n_vec[n].z << ")";
	}*/

	int face = 0;
	for (int i = 0; i < 24; i++) {
		if (i > ((4 * (face + 1)) - 1)) {
			face += 1;
		}
		m_vbo.AddData(&p_vec[i], sizeof(glm::vec3));
		m_vbo.AddData(&s_vec[i - face * 4], sizeof(glm::vec2));
		m_vbo.AddData(&n_vec[face], sizeof(glm::vec3));
	}

	// Upload data to GPU
	m_vbo.UploadDataToGPU(GL_STATIC_DRAW);
	GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride,
		(void*)(sizeof(glm::vec3) + sizeof(glm::vec2)));
}
void CRoof::Render()
{
	glBindVertexArray(m_vao);
	m_texture.Bind();
	// Call glDrawArrays to render each side
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	glDrawArrays(GL_TRIANGLE_STRIP, 4, 4);
	glDrawArrays(GL_TRIANGLE_STRIP, 8, 4);
	glDrawArrays(GL_TRIANGLE_STRIP, 12, 4);
	glDrawArrays(GL_TRIANGLE_STRIP, 16, 4);
	glDrawArrays(GL_TRIANGLE_STRIP, 20, 4);
}
void CRoof::Release()
{
	m_texture.Release();
	glDeleteVertexArrays(1, &m_vao);
	m_vbo.Release();
}