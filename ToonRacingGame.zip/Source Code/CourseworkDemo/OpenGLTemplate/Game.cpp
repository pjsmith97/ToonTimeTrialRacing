/* 
OpenGL Template for INM376 / IN3005
City University London, School of Mathematics, Computer Science and Engineering
Source code drawn from a number of sources and examples, including contributions from
 - Ben Humphrey (gametutorials.com), Michal Bubner (mbsoftworks.sk), Christophe Riccio (glm.g-truc.net)
 - Christy Quinn, Sam Kellett and others

 For educational use by Department of Computer Science, City University London UK.

 This template contains a skybox, simple terrain, camera, lighting, shaders, texturing

 Potential ways to modify the code:  Add new geometry types, shaders, change the terrain, load new meshes, change the lighting, 
 different camera controls, different shaders, etc.
 
 Template version 5.0a 29/01/2017
 Dr Greg Slabaugh (gregory.slabaugh.1@city.ac.uk) 

 version 6.0a 29/01/2019
 Dr Eddie Edwards (Philip.Edwards@city.ac.uk)
*/


#include "game.h"
#include <cstdlib>


// Setup includes
#include "HighResolutionTimer.h"
#include "GameWindow.h"

// Game includes
#include "Camera.h"
#include "Skybox.h"
#include "Plane.h"
#include "Shaders.h"
#include "FreeTypeFont.h"
#include "Sphere.h"
#include "MatrixStack.h"
#include "OpenAssetImportMesh.h"
#include "Audio.h"
#include "CatmullRom.h"
#include "CatmullRomPipe.h"
#include "Cube.h"
#include "Roof.h"
#include "Line.h"
#include "TriTent.h"
#include "ParticleSystem.h"

// Constructor
Game::Game()
{
	m_pSkybox = NULL;
	m_pCamera = NULL;
	m_pShaderPrograms = NULL;
	m_pPlanarTerrain = NULL;
	m_pFtFont = NULL;
	m_pBarrelMesh = NULL;
	m_pHorseMesh = NULL;
	m_pPalmMesh = NULL;
	m_pCarMesh = NULL;
	m_pTowerMesh = NULL;
	m_pRockMesh = NULL;
	m_pSphere = NULL;
	m_pHighResolutionTimer = NULL;
	m_pAudio = NULL;

	m_pCatmullRom = NULL;
	m_pCatmullRomPipe = NULL;

	m_particleSystem = NULL;

	m_pLine = NULL;
	m_pLine2 = NULL;
	m_pLine3 = NULL;
	m_pLine4 = NULL;

	m_pFighterMesh = NULL;

	m_pCube = NULL;

	m_pRoof = NULL;

	m_tent = NULL;

	m_dt = 0.0;
	m_t = 0;
	m_pt = 0;
	m_at = 0;
	m_endTime = 0.f;
	m_framesPerSecond = 0;
	m_frameCount = 0;
	m_elapsedTime = 0.0f;

	m_currentDistance = 0.0f;
	m_currentStrafeDist = 0.f;
	m_carSpeed = 0.025f;

	m_leftStrafe = false;
	m_rightStrafe = false;
	m_day = true;
	m_endGame = false;
	m_accelerate = false;
	m_firstPausePass = true;

	m_strafeSpeed = 0.02f;

	camera_view = 0;

	m_fontSize = 40.f;
	m_fontGrowth = true;

	m_pause = false;
}

// Destructor
Game::~Game() 
{ 
	//game objects
	delete m_pCamera;
	delete m_pSkybox;
	delete m_pPlanarTerrain;
	delete m_pFtFont;
	delete m_pBarrelMesh;
	delete m_pHorseMesh;
	delete m_pSphere;
	delete m_pAudio;
	delete m_pCatmullRom;
	delete m_pCatmullRomPipe;
	delete m_pFighterMesh;
	delete m_pCarMesh;
	delete m_pPalmMesh;
	delete m_pCube;
	delete m_pRoof;
	delete m_pLine;
	delete m_pLine2;
	delete m_pLine3;
	delete m_pLine4;
	delete m_tent;
	delete m_particleSystem;



	if (m_pShaderPrograms != NULL) {
		for (unsigned int i = 0; i < m_pShaderPrograms->size(); i++)
			delete (*m_pShaderPrograms)[i];
	}
	delete m_pShaderPrograms;

	/*if (m_pCatmullRoms != NULL) {
		for (unsigned int i = 0; i < m_pCatmullRoms->size(); i++)
			delete (*m_pCatmullRoms)[i];
	}
	delete m_pCatmullRoms;*/

	//setup objects
	delete m_pHighResolutionTimer;
}

// Initialisation:  This method only runs once at startup
void Game::Initialise() 
{
	// Set the clear colour and depth
	glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
	glClearDepth(1.0f);

	/// Create objects
	m_pCamera = new CCamera;
	m_pSkybox = new CSkybox;
	m_pShaderPrograms = new vector <CShaderProgram *>;
	m_pPlanarTerrain = new CPlane;
	m_pFtFont = new CFreeTypeFont;
	m_pBarrelMesh = new COpenAssetImportMesh;
	m_pHorseMesh = new COpenAssetImportMesh;
	m_pFighterMesh = new COpenAssetImportMesh;
	m_pTowerMesh = new COpenAssetImportMesh;
	m_pRockMesh = new COpenAssetImportMesh;
	m_pSphere = new CSphere;
	m_pAudio = new CAudio;
	m_pPalmMesh = new COpenAssetImportMesh;
	m_pCarMesh = new COpenAssetImportMesh;
	m_pCatmullRom = new CCatmullRom;
	m_pCatmullRomPipe = new CCatmullRomPipe;
	m_pCube = new CCube;
	m_pRoof = new CRoof;
	m_tent = new CTriTent;
	m_pLine = new CLine;
	m_pLine2 = new CLine;
	m_pLine3 = new CLine;
	m_pLine4 = new CLine;
	m_particleSystem = new CParticleSystem;

	m_spaceShipPosition = glm::vec3(0);
	m_spaceShipOrientation = glm::mat4(1.f);

	m_playerPosition = glm::vec3(0);
	m_playerOrientation = glm::mat4(1.f);

	m_pCatmullRom->CreateCentreline();
	m_pCatmullRom->CreateOffsetBounds();
	m_pCatmullRom->CreateWallPoints();
	m_pCatmullRom->CreateTrack("resources\\textures\\dirt.png"); //Downloaded from https://opengameart.org/content/4-hand-painted-ground-textures-dirt9png on March 27th
	m_pCatmullRom->CreateRightWall1Surface("resources\\textures\\sand.png"); //Downloaded from https://opengameart.org/content/hand-painted-sand-texture-0 on March 27th
	m_pCatmullRom->CreateRightWall2Surface("resources\\textures\\sand.png");
	m_pCatmullRom->CreateRightWall3Surface("resources\\textures\\sandy_rock.png"); //Downlaoded from https://opengameart.org/content/2k-handpainted-style-textures-hp04png
	m_pCatmullRom->CreateBottomWallSurface("resources\\textures\\sandy_rock.png");
	m_pCatmullRom->CreateLeftWall3Surface("resources\\textures\\sandy_rock.png");
	m_pCatmullRom->CreateLeftWall2Surface("resources\\textures\\sand.png");
	m_pCatmullRom->CreateLeftWall1Surface("resources\\textures\\sand.png");

	for (int i = 0; i < m_numRings; i++) {
		int random_place = rand() % (int)m_pCatmullRom->getWidth() / 2;
		if (i % 2) {
			random_place = -random_place;
		}
		m_ringOffset.push_back((float)random_place);
	}

	for (int i = 0; i < m_numSpikes; i++) {
		srand(3);
		int random_place = rand() % (int)m_pCatmullRom->getWidth() / 2;
		if (i % 2) {
			random_place = -random_place;
		}
		m_spikeOffset.push_back((float)random_place);
	}

	for (int i = 0; i < m_numRocks; i++) {
		float x = rand() % 200;
		float z = rand() % 200;
		if (i % 2) {
			x = -x;
		}
		if (i % 3) {
			z = -z;
		}

		m_rockPos.push_back(glm::vec3(x, 0.f, z));
	}
	


	m_pCatmullRomPipe->CreateCentreline();
	m_pCatmullRomPipe->CreatePipePoints();
	m_pCatmullRomPipe->CreatePipeSurface("resources\\textures\\waterf2.png"); //Downloaded from https://opengameart.org/node/31110
	

	RECT dimensions = m_gameWindow.GetDimensions();

	int width = dimensions.right - dimensions.left;
	int height = dimensions.bottom - dimensions.top;

	// Set the orthographic and perspective projection matrices based on the image size
	m_pCamera->SetOrthographicProjectionMatrix(width, height); 
	m_pCamera->SetPerspectiveProjectionMatrix(45.0f, (float) width / (float) height, 0.5f, 5000.0f);

	// Load shaders
	vector<CShader> shShaders;
	vector<string> sShaderFileNames;
	sShaderFileNames.push_back("mainShader.vert");
	sShaderFileNames.push_back("mainShader.frag");
	sShaderFileNames.push_back("textShader.vert");
	sShaderFileNames.push_back("textShader.frag");
	sShaderFileNames.push_back("sphereShader.vert");
	sShaderFileNames.push_back("sphereShader.frag");
	sShaderFileNames.push_back("palmShader.vert");
	sShaderFileNames.push_back("palmShader.frag");
	sShaderFileNames.push_back("carShader.vert");
	sShaderFileNames.push_back("carShader.frag");
	sShaderFileNames.push_back("carOutlineShader.vert");
	sShaderFileNames.push_back("carOutlineShader.frag");
	sShaderFileNames.push_back("hoopShader.vert");
	sShaderFileNames.push_back("hoopShader.frag");
	sShaderFileNames.push_back("particleShader.vert");
	sShaderFileNames.push_back("particleShader.frag");

	for (int i = 0; i < (int) sShaderFileNames.size(); i++) {
		string sExt = sShaderFileNames[i].substr((int) sShaderFileNames[i].size()-4, 4);
		int iShaderType;
		if (sExt == "vert") iShaderType = GL_VERTEX_SHADER;
		else if (sExt == "frag") iShaderType = GL_FRAGMENT_SHADER;
		else if (sExt == "geom") iShaderType = GL_GEOMETRY_SHADER;
		else if (sExt == "tcnl") iShaderType = GL_TESS_CONTROL_SHADER;
		else iShaderType = GL_TESS_EVALUATION_SHADER;
		CShader shader;
		shader.LoadShader("resources\\shaders\\"+sShaderFileNames[i], iShaderType);
		shShaders.push_back(shader);
	}

	// Create the main shader program
	CShaderProgram *pMainProgram = new CShaderProgram;
	pMainProgram->CreateProgram();
	pMainProgram->AddShaderToProgram(&shShaders[0]);
	pMainProgram->AddShaderToProgram(&shShaders[1]);
	pMainProgram->LinkProgram();
	m_pShaderPrograms->push_back(pMainProgram);

	// Create a shader program for fonts
	CShaderProgram *pFontProgram = new CShaderProgram;
	pFontProgram->CreateProgram();
	pFontProgram->AddShaderToProgram(&shShaders[2]);
	pFontProgram->AddShaderToProgram(&shShaders[3]);
	pFontProgram->LinkProgram();
	m_pShaderPrograms->push_back(pFontProgram);

	// Create the sphere shader program
	CShaderProgram* pSphereProgram = new CShaderProgram;
	pSphereProgram->CreateProgram();
	pSphereProgram->AddShaderToProgram(&shShaders[4]);
	pSphereProgram->AddShaderToProgram(&shShaders[5]);
	pSphereProgram->LinkProgram();
	m_pShaderPrograms->push_back(pSphereProgram);

	CShaderProgram* pPalmProgram = new CShaderProgram;
	pPalmProgram->CreateProgram();
	pPalmProgram->AddShaderToProgram(&shShaders[6]);
	pPalmProgram->AddShaderToProgram(&shShaders[7]);
	pPalmProgram->LinkProgram();
	m_pShaderPrograms->push_back(pPalmProgram);

	CShaderProgram* pCarProgram = new CShaderProgram;
	pCarProgram->CreateProgram();
	pCarProgram->AddShaderToProgram(&shShaders[8]);
	pCarProgram->AddShaderToProgram(&shShaders[9]);
	pCarProgram->LinkProgram();
	m_pShaderPrograms->push_back(pCarProgram);

	CShaderProgram* pCarOutlineProgram = new CShaderProgram;
	pCarOutlineProgram->CreateProgram();
	pCarOutlineProgram->AddShaderToProgram(&shShaders[10]);
	pCarOutlineProgram->AddShaderToProgram(&shShaders[11]);
	pCarOutlineProgram->LinkProgram();
	m_pShaderPrograms->push_back(pCarOutlineProgram);

	CShaderProgram* pHoopProgram = new CShaderProgram;
	pHoopProgram->CreateProgram();
	pHoopProgram->AddShaderToProgram(&shShaders[12]);
	pHoopProgram->AddShaderToProgram(&shShaders[13]);
	pHoopProgram->LinkProgram();
	m_pShaderPrograms->push_back(pHoopProgram);

	CShaderProgram* pParticleProgram = new CShaderProgram;
	pParticleProgram->CreateProgram();
	pParticleProgram->AddShaderToProgram(&shShaders[14]);
	pParticleProgram->AddShaderToProgram(&shShaders[15]);
	pParticleProgram->LinkProgram();
	m_pShaderPrograms->push_back(pParticleProgram);

	// You can follow this pattern to load additional shaders

	// Create the skybox
	// Skybox downloaded from http://www.akimbo.in/forum/viewtopic.php?f=10&t=9 on 27th March 2021
	m_pSkybox->Create(2500.0f);
	
	// Create the planar terrain
	m_pPlanarTerrain->Create("resources\\textures\\", "wavy_sand.png", 2000.0f, 2000.0f, 50.0f); // Texture downloaded from https://opengameart.org/content/4-hand-painted-ground-textures on 27th March 2021

	m_pFtFont->LoadSystemFont("SNAP____.TTF", 32);
	m_pFtFont->SetShaderProgram(pFontProgram);

	// Load some meshes in OBJ format
	m_pPalmMesh->Load("resources\\models\\palm\\palm.obj");  // Downloaded from https://opengameart.org/content/palm-tree-0 on 11 March 2021
	m_pCarMesh->Load("resources\\models\\car\\car.obj");  // Downloaded from https://www.cgtrader.com/free-3d-models/vehicle/industrial/cartoon-green-car on 19 March 2021
	m_pTowerMesh->Load("resources\\models\\Tower\\tower2.obj");  // Downloaded from https://www.cgtrader.com/free-3d-models/exterior/house/wooden-watch-tower-free-download on 8 May 2021
	m_pRockMesh->Load("resources\\models\\Rock\\rock.obj");  // Downloaded from https://opengameart.org/content/low-poly-rocks on 8 May 2021



	m_tent->Create("resources\\textures\\greentexture.jpg"); //Downloaded from https://www.publicdomainpictures.net/en/view-image.php?image=128535&picture=green-texture on May 1st

	m_particleSystem->Create(200, "resources\\textures\\spr_shield.png"); // Downloaded from https://opengameart.org/content/shield-effect on May 8 2021

	// Create a sphere
	glEnable(GL_CULL_FACE);

	// Initialise audio and play background music
	m_pAudio->Initialise();
	m_pAudio->LoadEventSound("resources\\Audio\\Boing.wav");					// Royalty free sound from freesound.org
	m_pAudio->LoadMusicStream("resources\\Audio\\DST-Garote.mp3");	// Royalty free music from http://www.nosoapradio.us/
	//m_pAudio->PlayMusicStream();
}

// Render method runs repeatedly in a loop
void Game::Render() 
{
	
	// Clear the buffers and enable depth testing (z-buffering)
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_STENCIL_TEST);

	//Stencil Code
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
	glStencilMask(0x00);

	// Set up a matrix stack
	glutil::MatrixStack modelViewMatrixStack;
	modelViewMatrixStack.SetIdentity();

	// Use the main shader program 
	CShaderProgram *pMainProgram = (*m_pShaderPrograms)[0];
	pMainProgram->UseProgram();
	pMainProgram->SetUniform("bUseTexture", true);
	pMainProgram->SetUniform("sampler0", 0);
	// Note: cubemap and non-cubemap textures should not be mixed in the same texture unit.  Setting unit 10 to be a cubemap texture.
	int cubeMapTextureUnit = 10; 
	pMainProgram->SetUniform("CubeMapTex", cubeMapTextureUnit);
	

	// Set the projection matrix
	pMainProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());

	// Call LookAt to create the view matrix and put this on the modelViewMatrix stack. 
	// Store the view matrix and the normal matrix associated with the view matrix for later (they're useful for lighting -- since lighting is done in eye coordinates)
	modelViewMatrixStack.LookAt(m_pCamera->GetPosition(), m_pCamera->GetView(), m_pCamera->GetUpVector());
	glm::mat4 viewMatrix = modelViewMatrixStack.Top();
	glm::mat3 viewNormalMatrix = m_pCamera->ComputeNormalMatrix(viewMatrix);

	float daylight;
	float color;
	float spotlight;

	if (m_day) {
		daylight = 1.f;
		color = 1.f;
		spotlight = 0.f;
	}

	else {
		daylight = 0.2f;
		color = 0.f;
		spotlight = 1.f;
	}

	
	// Set light and materials in main shader program
	glm::vec4 lightPosition1 = glm::vec4(-100, 100, -100, 1); // Position of light source *in world coordinates*
	glm::vec4 spotlightPosition1 = glm::vec4(m_playerPosition + m_playerSide * -3.f + m_playerUp + m_playerDirection * 2.f, 1.0);
	glm::vec4 spotlightPosition2 = glm::vec4(m_playerPosition + m_playerSide * 0.f + m_playerUp + m_playerDirection * 2.f, 1.0);
	pMainProgram->SetUniform("light1.position", viewMatrix*lightPosition1); // Position of light source *in eye coordinates*
	pMainProgram->SetUniform("light1.La", glm::vec3(daylight));		// Ambient colour of light
	pMainProgram->SetUniform("light1.Ld", glm::vec3(daylight));		// Diffuse colour of light
	pMainProgram->SetUniform("light1.Ls", glm::vec3(daylight));		// Specular colour of light
	pMainProgram->SetUniform("material1.Ma", glm::vec3(0.9f));	// Ambient material reflectance
	pMainProgram->SetUniform("material1.Md", glm::vec3(0.f));	// Diffuse material reflectance
	pMainProgram->SetUniform("material1.Ms", glm::vec3(0.f));	// Specular material reflectance
	pMainProgram->SetUniform("material1.shininess", 30.0f);		// Shininess material property
	pMainProgram->SetUniform("levels", 4);
	pMainProgram->SetUniform("u_colorFactor", color);
		

	// Render the skybox and terrain with full ambient reflectance 
	modelViewMatrixStack.Push();
		pMainProgram->SetUniform("renderSkybox", true);
		// Translate the modelview matrix to the camera eye point so skybox stays centred around camera
		glm::vec3 vEye = m_pCamera->GetPosition();
		modelViewMatrixStack.Translate(vEye);
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pSkybox->Render(cubeMapTextureUnit);
		pMainProgram->SetUniform("renderSkybox", false);
	modelViewMatrixStack.Pop();

	// Render the planar terrain
	modelViewMatrixStack.Push();
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pPlanarTerrain->Render();
	modelViewMatrixStack.Pop();


	//Stencil Code
	glStencilOp(GL_KEEP, GL_REPLACE, GL_REPLACE);
	glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
	glStencilMask(0x00);

	// Turn on diffuse + specular materials
	pMainProgram->SetUniform("material1.Ma", glm::vec3(0.5f));	// Ambient material reflectance
	pMainProgram->SetUniform("material1.Md", glm::vec3(0.9f));	// Diffuse material reflectance
	pMainProgram->SetUniform("material1.Ms", glm::vec3(1.0f));	// Specular material reflectance	

	//SpotLight centered on player car
	pMainProgram->SetUniform("spotLight1.position", viewMatrix * spotlightPosition1); // Light1 position in eye coordinates
	pMainProgram->SetUniform("spotLight2.position", viewMatrix * spotlightPosition2); // Light2 position in eye coordinates
	pMainProgram->SetUniform("spotLight1.La", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("spotLight1.Ld", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("spotLight1.Ls", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("material1.sMa", glm::vec3(0.001f));	// Spotlight Ambient material reflectance
	pMainProgram->SetUniform("material1.sMd", glm::vec3(0.9f));	// SpotLight Diffuse material reflectance
	pMainProgram->SetUniform("material1.sMs", glm::vec3(1.0f));	// SpotLight Specular material reflectance
	pMainProgram->SetUniform("spotLight1.direction",
		glm::normalize(viewNormalMatrix * m_playerDirection));
	pMainProgram->SetUniform("spotLight1.exponent", 10.0f);
	pMainProgram->SetUniform("spotLight1.cutoff", 20.0f);
	pMainProgram->SetUniform("spotLight2.La", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("spotLight2.Ld", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("spotLight2.Ls", glm::vec3(spotlight, spotlight, 0.0f));
	pMainProgram->SetUniform("spotLight2.direction",
		glm::normalize(viewNormalMatrix * m_playerDirection));
	pMainProgram->SetUniform("spotLight2.exponent", 10.0f);
	pMainProgram->SetUniform("spotLight2.cutoff", 20.0f);

	// Render spikes

	float spike_interval = m_pCatmullRom->getMaxDistance() / m_numSpikes;
	for (int i = 1; i <= m_numSpikes; i++) {
		float spike_distance = spike_interval * i;
		float viewDistance = spike_distance - 0.1f;
		glm::vec3 p;
		glm::vec3 pNext;
		glm::vec3 pUp;
		m_pCatmullRom->Sample(spike_distance, p, pUp);
		m_pCatmullRom->Sample(viewDistance, pNext);
		glm::vec3 viewDir = glm::normalize(pNext - p);

		glm::vec3 eyeT = viewDir;
		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, pUp));
		glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));


		modelViewMatrixStack.Push();
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

			glm::vec3 pos = p + eyeN * m_spikeOffset[i - 1];
			
			if (m_spikePos.size() < m_numSpikes) {
				m_spikePos.push_back(pos);
			}
			
			modelViewMatrixStack.Translate(pos);
			modelViewMatrixStack *= glm::mat4(glm::mat3(eyeT, -eyeB, eyeN));
			/*modelViewMatrixStack *= m_playerOrientation;*/
			modelViewMatrixStack.Scale(5.f);

			pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
			pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
			m_tent->Render();
		modelViewMatrixStack.Pop();
	}
	
	// Render CatmullRom
	modelViewMatrixStack.Push();
		pMainProgram->SetUniform("bUseTexture", false); // turn off texturing
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix",
			m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		// Render your object here

		//m_pCatmullRom->RenderCentreline();
		//m_pCatmullRom->RenderOffsetCurves();
		//m_pCatmullRomPipe->RenderCentreline();

		//m_pCatmullRom->RenderWallPoints();
		//m_pCatmullRomPipe->RenderPipePoints();
		pMainProgram->SetUniform("bUseTexture", true);
		
		m_pCatmullRom->RenderTrack();
		m_pCatmullRom->RenderRightWall1Surface();
		m_pCatmullRom->RenderRightWall2Surface();
		m_pCatmullRom->RenderRightWall3Surface();
		m_pCatmullRom->RenderBottomWallSurface();
		m_pCatmullRom->RenderLeftWall3Surface();
		m_pCatmullRom->RenderLeftWall2Surface();
		m_pCatmullRom->RenderLeftWall1Surface();


		// Switch to Hoop Program
		CShaderProgram* pHoopProgram = (*m_pShaderPrograms)[6];
		pHoopProgram->UseProgram();
		pHoopProgram->SetUniform("sampler0", 0);

		// Set light and materials in sphere programme
		pHoopProgram->SetUniform("material1.Ma", glm::vec3(1.0f, 1.0f, 1.0f));
		pHoopProgram->SetUniform("material1.Md", glm::vec3(1.0f, 1.0f, 1.0f));
		pHoopProgram->SetUniform("material1.Ms", glm::vec3(1.0f, 1.0f, 1.0f));
		pHoopProgram->SetUniform("material1.shininess", 50.0f);
		pHoopProgram->SetUniform("light1.La", glm::vec3(daylight/2));
		pHoopProgram->SetUniform("light1.Ld", glm::vec3(daylight));
		pHoopProgram->SetUniform("light1.Ls", glm::vec3(daylight));
		pHoopProgram->SetUniform("light1.position", viewMatrix* lightPosition1);

		//SpotLight centered on player car
		pHoopProgram->SetUniform("spotLight1.position", viewMatrix * spotlightPosition1); // Light position in eye coordinates
		pHoopProgram->SetUniform("spotLight2.position", viewMatrix * spotlightPosition2); // Light2 position in eye coordinates
		pHoopProgram->SetUniform("spotLight1.La", glm::vec3(spotlight));
		pHoopProgram->SetUniform("spotLight1.Ld", glm::vec3(spotlight));
		pHoopProgram->SetUniform("spotLight1.Ls", glm::vec3(spotlight));
		pHoopProgram->SetUniform("material1.sMa", glm::vec3(0.001f));	// Spotlight Ambient material reflectance
		pHoopProgram->SetUniform("material1.sMd", glm::vec3(0.9f));	// SpotLight Diffuse material reflectance
		pHoopProgram->SetUniform("material1.sMs", glm::vec3(1.0f));	// SpotLight Specular material reflectance
		pHoopProgram->SetUniform("spotLight1.direction",
			glm::normalize(viewNormalMatrix * m_playerDirection));
		pHoopProgram->SetUniform("spotLight1.exponent", 10.0f);
		pHoopProgram->SetUniform("spotLight1.cutoff", 20.0f);
		pHoopProgram->SetUniform("spotLight2.La", glm::vec3(spotlight, spotlight, 0.0f));
		pHoopProgram->SetUniform("spotLight2.Ld", glm::vec3(spotlight, spotlight, 0.0f));
		pHoopProgram->SetUniform("spotLight2.Ls", glm::vec3(spotlight, spotlight, 0.0f));
		pHoopProgram->SetUniform("spotLight2.direction",
			glm::normalize(viewNormalMatrix * m_playerDirection));
		pHoopProgram->SetUniform("spotLight2.exponent", 10.0f);
		pHoopProgram->SetUniform("spotLight2.cutoff", 20.0f);
		pHoopProgram->SetUniform("t", m_at * 2);
		pHoopProgram->SetUniform("levels", 4);
		pHoopProgram->SetUniform("u_colorFactor", color);
		pHoopProgram->SetUniform("bUseTexture", true);


		
		float ring_interval = m_pCatmullRom->getMaxDistance() / m_numRings;
		for (int i = 1; i <= m_numRings; i++) {
			float ring_distance = ring_interval*i;
			float viewDistance = ring_distance - 0.1f;
			glm::vec3 p;
			glm::vec3 pNext;
			glm::vec3 pUp;
			m_pCatmullRom->Sample(ring_distance, p, pUp);
			m_pCatmullRom->Sample(viewDistance, pNext);
			glm::vec3 viewDir = glm::normalize(pNext - p);

			glm::vec3 eyeT = viewDir;
			glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, pUp));
			glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));

			modelViewMatrixStack.Push();
				glEnable(GL_BLEND);
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				
				glm::vec3 pos = p + eyeN * m_ringOffset[i - 1];

				if (m_ringPos.size() < m_numRings) {
					m_ringPos.push_back(pos);
				}

				modelViewMatrixStack.Translate(p + (-eyeB * 2.f) + eyeN * m_ringOffset[i-1]);
				modelViewMatrixStack.RotateZ(acos(-1) / 2);
				//float rot_angle = acos(glm::dot(eyeT, glm::vec3(1, 0, 0)));
				modelViewMatrixStack.RotateX(ring_rotation);
				//modelViewMatrixStack.LookAt(p, p + (10.f * viewDir), pUp);
				
				modelViewMatrixStack.Scale(0.2f);
				//pMainProgram->SetUniform("bUseTexture", true);
				pHoopProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
				pHoopProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
				pHoopProgram->SetUniform("matrices.normalMatrix",
					m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
				m_pCatmullRomPipe->RenderPipeSurface();
			modelViewMatrixStack.Pop();
		}
		
	modelViewMatrixStack.Pop();

	// Tower Rendering
	modelViewMatrixStack.Push();
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		pHoopProgram->SetUniform("bUseTexture", true);
		modelViewMatrixStack.Translate(glm::vec3(150.f, -5.f, 40.f));
		modelViewMatrixStack.Scale(6.5f);
		pHoopProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
		pHoopProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pHoopProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pTowerMesh->Render();
	modelViewMatrixStack.Pop();

	modelViewMatrixStack.Push();
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		pHoopProgram->SetUniform("bUseTexture", true);
		modelViewMatrixStack.Translate(glm::vec3(-150.f, -5.f, 90.f));
		modelViewMatrixStack.Scale(6.5f);
		pHoopProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
		pHoopProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pHoopProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pTowerMesh->Render();
	modelViewMatrixStack.Pop();

	// Render Rock mesh
	for (int r = 0; r < m_numRocks; r++) {
		modelViewMatrixStack.Push();
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			pHoopProgram->SetUniform("bUseTexture", true);
			modelViewMatrixStack.Translate(m_rockPos[r]);
			modelViewMatrixStack.Scale(2.5f);
			pHoopProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
			pHoopProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
			pHoopProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
			m_pRockMesh->Render();
		modelViewMatrixStack.Pop();
	}
	


	// Switch to Palm program
	CShaderProgram* pPalmProgram = (*m_pShaderPrograms)[3];
	pPalmProgram->UseProgram();
	pPalmProgram->SetUniform("sampler0", 0);

	// Set light and materials in sphere programme
	pPalmProgram->SetUniform("material1.Ma", glm::vec3(1.0f, 1.0f, 1.0f));
	pPalmProgram->SetUniform("material1.Md", glm::vec3(1.0f, 1.0f, 1.0f));
	pPalmProgram->SetUniform("material1.Ms", glm::vec3(1.0f, 1.0f, 1.0f));
	pPalmProgram->SetUniform("material1.shininess", 50.0f);
	pPalmProgram->SetUniform("light1.La", glm::vec3(0.5f, 0.5f, 0.5f));
	pPalmProgram->SetUniform("light1.Ld", glm::vec3(1.0f, 1.0f, 1.0f));
	pPalmProgram->SetUniform("light1.Ls", glm::vec3(1.0f, 1.0f, 1.0f));
	pPalmProgram->SetUniform("light1.position", viewMatrix * lightPosition1);
	pPalmProgram->SetUniform("t", m_at*4);
	pPalmProgram->SetUniform("levels", 4);
	pPalmProgram->SetUniform("spotLight1.position", viewMatrix *
		spotlightPosition1); // Light position in eye coordinates
	pPalmProgram->SetUniform("spotLight1.La", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("spotLight1.Ld", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("spotLight1.Ls", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("material1.sMa", glm::vec3(0.001f)); // Spotlight Ambient material reflectance
	pPalmProgram->SetUniform("material1.sMd", glm::vec3(0.9f));	// SpotLight Diffuse material reflectance
	pPalmProgram->SetUniform("material1.sMs", glm::vec3(1.0f));	// SpotLight Specular material reflectance
	pPalmProgram->SetUniform("spotLight1.direction",
		glm::normalize(viewNormalMatrix * m_playerDirection));
	pPalmProgram->SetUniform("spotLight1.exponent", 10.0f);
	pPalmProgram->SetUniform("spotLight1.cutoff", 20.0f);
	pPalmProgram->SetUniform("spotLight2.La", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("spotLight2.Ld", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("spotLight2.Ls", glm::vec3(spotlight, spotlight, 0.0f));
	pPalmProgram->SetUniform("spotLight2.direction",
		glm::normalize(viewNormalMatrix* m_playerDirection));
	pPalmProgram->SetUniform("spotLight2.exponent", 10.0f);
	pPalmProgram->SetUniform("spotLight2.cutoff", 20.0f);
	pPalmProgram->SetUniform("u_colorFactor", color);

	int num_palms = 8;
	float palm_interval = m_pCatmullRom->getMaxDistance() / num_palms;
	for (int i = 1; i <= num_palms; i++) {
		float palm_distance = palm_interval * i;
		float viewDistance = palm_distance - 0.1f;
		glm::vec3 p;
		glm::vec3 pNext;
		glm::vec3 pUp;
		m_pCatmullRom->Sample(palm_distance, p, pUp);
		m_pCatmullRom->Sample(viewDistance, pNext);
		glm::vec3 viewDir = glm::normalize(pNext - p);

		glm::vec3 eyeT = viewDir;
		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, pUp));
		glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));

		modelViewMatrixStack.Push();
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			pPalmProgram->SetUniform("bUseTexture", true);
			if (i % 2 == 0) {
				modelViewMatrixStack.Translate(p + (m_pCatmullRom->getWidth() / 2 + 1) * eyeN);
			}

			else {
				modelViewMatrixStack.Translate(p - (m_pCatmullRom->getWidth() / 2 + 1) * eyeN);
			}
			
			modelViewMatrixStack *= glm::mat4(glm::mat3(eyeT, -eyeB, eyeN));

			modelViewMatrixStack.Scale(2.5f);
			pPalmProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
			pPalmProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
			pPalmProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
			m_pPalmMesh->Render();
		modelViewMatrixStack.Pop();
	}

	
	

	CShaderProgram* pCarProgram = (*m_pShaderPrograms)[4];

	pCarProgram->UseProgram();
	pCarProgram->SetUniform("sampler0", 0);

	// Set up Stencil priority
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
	glStencilFunc(GL_ALWAYS, 1, 0xFF);
	glStencilMask(0xFF);

	// Set light and materials in sphere programme
	pCarProgram->SetUniform("material1.Ma", glm::vec3(1.0f, 1.0f, 1.0f));
	pCarProgram->SetUniform("material1.Md", glm::vec3(1.0f, 1.0f, 1.0f));
	pCarProgram->SetUniform("material1.Ms", glm::vec3(1.0f, 1.0f, 1.0f));
	pCarProgram->SetUniform("material1.shininess", 50.0f);
	pCarProgram->SetUniform("light1.La", glm::vec3(0.5f, 0.5f, 0.5f));
	pCarProgram->SetUniform("light1.Ld", glm::vec3(1.0f, 1.0f, 1.0f));
	pCarProgram->SetUniform("light1.Ls", glm::vec3(1.0f, 1.0f, 1.0f));
	pCarProgram->SetUniform("light1.position", viewMatrix * lightPosition1);
	pCarProgram->SetUniform("t", m_at*2);
	pCarProgram->SetUniform("levels", 4);
	pCarProgram->SetUniform("u_colorFactor", color);

	modelViewMatrixStack.Push();
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		pCarProgram->SetUniform("bUseTexture", true);
		modelViewMatrixStack.Push();
		glm::vec3 dum_pos = glm::vec3(60.0f, 0.0f, 50.0f);
			modelViewMatrixStack.Translate(m_playerPosition);
			modelViewMatrixStack *= m_playerOrientation;
			modelViewMatrixStack.RotateY(acos(-1)/2);
			modelViewMatrixStack.Scale(10.0f);
			pCarProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
			pCarProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
			pCarProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
			m_pCarMesh->Render();
		modelViewMatrixStack.Pop();

		modelViewMatrixStack.Push();
			glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
			glStencilMask(0x00);
			glDisable(GL_DEPTH_TEST);
			CShaderProgram* pCarOutlineProgram = (*m_pShaderPrograms)[5];
			pCarOutlineProgram->UseProgram();
			pCarOutlineProgram->SetUniform("t", m_at*2);
			glm::vec3 outline_displacement = glm::vec3(-0.05, 0.f, 0.05f);
			outline_displacement = m_playerSide * 0.05f + m_playerDirection * 0.05f;
			modelViewMatrixStack.Translate(m_playerPosition + outline_displacement);
			modelViewMatrixStack *= m_playerOrientation;
			modelViewMatrixStack.RotateY(acos(-1)/2);
			modelViewMatrixStack.Scale(10.5f);
			pCarOutlineProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
			pCarOutlineProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
			pCarOutlineProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
			m_pCarMesh->Render();
			glStencilMask(0xFF);
			glStencilFunc(GL_ALWAYS, 1, 0xFF);
			glEnable(GL_DEPTH_TEST);
		modelViewMatrixStack.Pop();

	modelViewMatrixStack.Pop();


	// Render Particle Effect
	CShaderProgram* pParticleProgram = (*m_pShaderPrograms)[7];

	pParticleProgram->UseProgram();
	pParticleProgram->SetUniform("ParticleTex", 0);
	pParticleProgram->SetUniform("Time", m_pt); // Will only render if car accelerates
	pParticleProgram->SetUniform("Gravity", glm::vec3(0.0, -0.05, 0.0));
	pParticleProgram->SetUniform("ParticleLifetime", 2.f);
	pParticleProgram->SetUniform("bUseTexture", true);

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	modelViewMatrixStack.Push();
		modelViewMatrixStack.Translate(m_playerPosition - 1.5f*m_playerSide -m_playerUp);
		modelViewMatrixStack *= m_playerOrientation;
		pParticleProgram->SetUniform("projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
		pParticleProgram->SetUniform("modMatrix", modelViewMatrixStack.Top());
		m_particleSystem->Render();
	modelViewMatrixStack.Pop();

	glEnable(GL_DEPTH_TEST);
		
	// Draw the 2D graphics after the 3D graphics
	//DisplayFrameRate();
	CShaderProgram* fontProgram = (*m_pShaderPrograms)[1];
	RECT dimensions = m_gameWindow.GetDimensions();
	int height = dimensions.bottom - dimensions.top;

	fontProgram->UseProgram();

	if (!m_endGame) {
		//Lap text shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 0.0f, 0.0f, 1.0f));
			m_pFtFont->Render(20, height - 78, 40, "Lap: %i / 3", m_pCatmullRom->CurrentLap(m_currentDistance) + 1);
		modelViewMatrixStack.Pop();

		//Lap Text Rendered over shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 1.0f, 0.5f, 1.0f));
			m_pFtFont->Render(18, height - 80, 40, "Lap: %i / 3", m_pCatmullRom->CurrentLap(m_currentDistance) + 1);
		modelViewMatrixStack.Pop();

		// Timer Text Shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 0.f, 0.f, 1.0f));
			if (int(m_t) % 60 < 10) {
				m_pFtFont->Render(602, height - 80, 40, "%i : 0%i", int(m_t / 60), int(m_t) % 60);
			}
			else {
				m_pFtFont->Render(602, height - 80, 40, "%i : %i", int(m_t / 60), int(m_t) % 60);
			}

		modelViewMatrixStack.Pop();

		// Timer Text Rendered over shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 1.f, 1.f, 1.0f));
			if (int(m_t) % 60 < 10) {
				m_pFtFont->Render(600, height - 80, 40, "%i : 0%i", int(m_t / 60), int(m_t) % 60);
			}
			else {
				m_pFtFont->Render(600, height - 80, 40, "%i : %i", int(m_t / 60), int(m_t) % 60);
			}

		modelViewMatrixStack.Pop();

	}

	else {
		// Fin Title Text Shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 0.f, 0.f, 1.0f));
			m_pFtFont->Render(304, height - 80, 80, "FIN");
		modelViewMatrixStack.Pop();
		
		//Fin title text rendered over shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 1.f, 1.f, 1.0f));
			m_pFtFont->Render(300, height - 80, 80, "FIN");
		modelViewMatrixStack.Pop();


		// Finish time Text shadow
		modelViewMatrixStack.Push();
		glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 0.f, 0.f, 1.0f));
			if (int(m_t) % 60 < 10) {
				m_pFtFont->Render(284, height - 300, 70, "%i : 0%i", int(m_endTime / 60), int(m_t) % 60);
			}
			else {
				m_pFtFont->Render(284, height - 300, 70, "%i : %i", int(m_endTime / 60), int(m_t) % 60);
			}
		modelViewMatrixStack.Pop();

		// Finish time Text Rendered over shadow
		modelViewMatrixStack.Push();
			glDisable(GL_DEPTH_TEST);
			fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
			fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
			fontProgram->SetUniform("vColour", glm::vec4(0.0f, 1.f, 1.f, 1.0f));
			if (int(m_t) % 60 < 10) {
				m_pFtFont->Render(280, height - 300, 70, "%i : 0%i", int(m_endTime / 60), int(m_t) % 60);
			}
			else {
				m_pFtFont->Render(280, height - 300, 70, "%i : %i", int(m_endTime / 60), int(m_t) % 60);
			}
		modelViewMatrixStack.Pop();
	}
	
	// Swap buffers to show the rendered image
	SwapBuffers(m_gameWindow.Hdc());		

}

// Update method runs repeatedly with the Render method
void Game::Update() 
{
	// Update the camera using the amount of time that has elapsed to avoid framerate dependent motion
	//m_pCamera->Update(m_dt);
	glm::vec3 p;
	glm::vec3 pNext;
	glm::vec3 pNextNext;
	glm::vec3 pUp;
	glm::vec3 pNextUp;
	glm::vec3 viewDir;
	glm::vec3 eyeT;
	glm::vec3 eyeN;
	glm::vec3 eyeB;
	glm::vec3 eyePT;
	glm::vec3 eyePN;
	glm::vec3 eyePB;
	glm::vec3 viewPlayerDir;


	if (!m_pause) {
		m_currentDistance += m_dt * m_carSpeed;
	}
	
	float viewDistance = m_currentDistance + 10.f;
	float playerViewDistance = viewDistance + 1.f;
		
	m_pCatmullRom->Sample(m_currentDistance, p, pUp);
	m_pCatmullRom->Sample(viewDistance, pNext, pNextUp);
	m_pCatmullRom->Sample(playerViewDistance, pNextNext);
	viewDir = glm::normalize(pNext - p);
	viewPlayerDir = glm::normalize(pNextNext - pNext);

	eyeT = viewDir;
	eyeN = glm::normalize(glm::cross(eyeT, pUp));
	eyeB = glm::normalize(glm::cross(eyeT, eyeN));


	eyePT = viewPlayerDir;
	eyePN = glm::normalize(glm::cross(eyePT, pNextUp));
	eyePB = glm::normalize(glm::cross(eyePT, eyePN));

	// Control player strafe amount
	float spare_dist = m_currentStrafeDist;
	if (m_rightStrafe) {
		m_currentStrafeDist += m_dt * m_strafeSpeed;
		if (m_currentStrafeDist > m_pCatmullRom->getWidth() / 2) {
			m_currentStrafeDist = spare_dist;
		}
	}

	else if (m_leftStrafe) {
		m_currentStrafeDist -= m_dt * m_strafeSpeed;
		if (m_currentStrafeDist < -m_pCatmullRom->getWidth() / 2) {
			m_currentStrafeDist = spare_dist;
		}
	}

	if (!m_pause && !m_endGame) {
		m_playerPosition = pNext + eyePN * 1.5f + eyePN * m_currentStrafeDist;
		m_playerOrientation = glm::mat4(glm::mat3(eyePT, -eyePB, eyePN));
		m_playerDirection = eyePT;
		m_playerUp = -eyePB;
		m_playerSide = eyePN;

		for (int pos = 0; pos < m_spikePos.size(); pos++) {
			float length = glm::length(m_playerPosition - m_spikePos[pos]);

			if (length < 3.5f) {
				float spare_speed = m_carSpeed;
				m_carSpeed -= 0.0001f * (float)m_dt;
				if (m_carSpeed <= 0.025f) {
					m_carSpeed = spare_speed;
				}
			}
		}

		for (int pos = 0; pos < m_ringPos.size(); pos++) {
			float length = glm::length(m_playerPosition - m_ringPos[pos]);

			if (length < 4.f) {
				float spare_speed = m_carSpeed;
				m_carSpeed += 0.0001f * (float)m_dt;
				if (m_carSpeed >= 0.075f) {
					m_carSpeed = spare_speed;
				}
				else {
					m_pt = 0;
					m_accelerate = true;
				}
			}
		}
	}

	//Third Person View
	if (camera_view == 0 && !m_pause) {
		glm::vec3 new_camPos = p + (7.f * -eyeB);

		m_pCamera->Set(new_camPos, p + (10.f * viewDir) + 2.f * -eyeB, -eyeB);
	}

	//First Person View
	else if (camera_view == 1 && !m_pause) {
		glm::vec3 new_camPos = m_playerPosition - eyePN * 2.f + -eyePB * 2.3f + eyePT*2.f;
		m_pCamera->Set(new_camPos, m_playerPosition + (20.f * viewPlayerDir) + 2.f * -eyeB, -eyePB);
	}


	//Top View
	else if (camera_view == 2 && !m_pause) {
		glm::vec3 new_camPos = m_playerPosition + -eyePN * 1.f + glm::vec3(0, 1, 0) * 50.f;
		m_pCamera->Set(new_camPos, m_playerPosition + -eyePN * 1.f, m_playerDirection);
	}

	//Free Camera View
	else if (camera_view == 3 || m_pause) {
		
		if (m_firstPausePass) {
			m_pCamera->Set(m_pCamera->GetPosition(), glm::vec3(0, 0, 0),
				glm::vec3(0, 1, 0));
			m_firstPausePass = false;
		}
		else {
			m_pCamera->Set(m_pCamera->GetPosition(), m_pCamera->GetView(),
				glm::vec3(0, 1, 0));
		}

		m_pCamera->Update(m_dt);
	}

	m_pAudio->Update(); // Control Game Audio

	m_at += 0.001f * (float)m_dt; // increment animation timer

	if (!m_endGame && !m_pause) {
		m_t += 0.001f * (float)m_dt; // Timer float
	}
	
	//Only increment particle timer if the car accelerates from a ring
	if (m_accelerate) {
		m_pt += 0.001f * (float)m_dt;
	}

	ring_rotation += 0.001f * (float)m_dt; //increment ring rotation

	if (3 == m_pCatmullRom->CurrentLap(m_currentDistance) && !m_endGame) { // Set up game end screen
		m_endGame = !m_endGame;
		camera_view = 0;
		m_endTime = m_t;
	}

}



void Game::DisplayFrameRate()
{


	CShaderProgram *fontProgram = (*m_pShaderPrograms)[1];

	RECT dimensions = m_gameWindow.GetDimensions();
	int height = dimensions.bottom - dimensions.top;

	// Increase the elapsed time and frame counter
	m_elapsedTime += m_dt;
	m_frameCount++;

	// Now we want to subtract the current time by the last time that was stored
	// to see if the time elapsed has been over a second, which means we found our FPS.
	if (m_elapsedTime > 1000)
    {
		m_elapsedTime = 0;
		m_framesPerSecond = m_frameCount;

		// Reset the frames per second
		m_frameCount = 0;
    }

	if (m_framesPerSecond > 0) {
		// Use the font shader program and render the text
		fontProgram->UseProgram();
		glDisable(GL_DEPTH_TEST);
		fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
		fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
		fontProgram->SetUniform("vColour", glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));
		m_pFtFont->Render(20, height - 20, 20, "FPS: %d", m_framesPerSecond);
	}
}

// The game loop runs repeatedly until game over
void Game::GameLoop()
{
	/*
	// Fixed timer
	dDt = pHighResolutionTimer->Elapsed();
	if (dDt > 1000.0 / (double) Game::FPS) {
		pHighResolutionTimer->Start();
		Update();
		Render();
	}
	*/
	
	
	// Variable timer
	m_pHighResolutionTimer->Start();
	Update();
	Render();
	m_dt = m_pHighResolutionTimer->Elapsed();
	

}


WPARAM Game::Execute() 
{
	m_pHighResolutionTimer = new CHighResolutionTimer;
	m_gameWindow.Init(m_hInstance);

	if(!m_gameWindow.Hdc()) {
		return 1;
	}

	Initialise();

	m_pHighResolutionTimer->Start();

	
	MSG msg;

	while(1) {													
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) { 
			if(msg.message == WM_QUIT) {
				break;
			}

			TranslateMessage(&msg);	
			DispatchMessage(&msg);
		} else if (m_appActive) {
			GameLoop();
		} 
		else Sleep(200); // Do not consume processor power if application isn't active
	}

	m_gameWindow.Deinit();

	return(msg.wParam);
}

LRESULT Game::ProcessEvents(HWND window,UINT message, WPARAM w_param, LPARAM l_param) 
{
	LRESULT result = 0;

	switch (message) {


	case WM_ACTIVATE:
	{
		switch(LOWORD(w_param))
		{
			case WA_ACTIVE:
			case WA_CLICKACTIVE:
				m_appActive = true;
				m_pHighResolutionTimer->Start();
				break;
			case WA_INACTIVE:
				m_appActive = false;
				break;
		}
		break;
		}

	case WM_SIZE:
			RECT dimensions;
			GetClientRect(window, &dimensions);
			m_gameWindow.SetDimensions(dimensions);
		break;

	case WM_PAINT:
		PAINTSTRUCT ps;
		BeginPaint(window, &ps);
		EndPaint(window, &ps);
		break;

	case WM_KEYDOWN:
		switch(w_param) {
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		case '1':
			if (!m_endGame) {
				m_leftStrafe = true;
			}
			break;
		case '2':
			if (!m_endGame) {
				m_rightStrafe = true;
			}
			break;
		case '0':
			if (!m_endGame) {
				camera_view += 1;
				if (camera_view > 3) {
					camera_view = 0;
					if (!m_firstPausePass) {
						m_firstPausePass = true;
					}
				}
			}
			break;

		case '6':
			if (!m_endGame) {
				m_pause = !m_pause;
				if (!m_firstPausePass) {
					m_firstPausePass = true;
				}
			}
			break;
		case VK_F1:
			//m_pAudio->PlayEventSound();
			break;

		case '9':
			m_day = !m_day;
			break;
		}
		break;

	case WM_KEYUP:
		switch (w_param) {
		
		case '1':
			m_leftStrafe = false;
			break;
		case '2':
			m_rightStrafe = false;
			break;
		}
		break;
	
	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		result = DefWindowProc(window, message, w_param, l_param);
		break;
	}

	return result;
}

Game& Game::GetInstance() 
{
	static Game instance;

	return instance;
}

void Game::SetHinstance(HINSTANCE hinstance) 
{
	m_hInstance = hinstance;
}

LRESULT CALLBACK WinProc(HWND window, UINT message, WPARAM w_param, LPARAM l_param)
{
	return Game::GetInstance().ProcessEvents(window, message, w_param, l_param);
}

int WINAPI WinMain(HINSTANCE hinstance, HINSTANCE, PSTR, int) 
{
	Game &game = Game::GetInstance();
	game.SetHinstance(hinstance);

	return game.Execute();
}
