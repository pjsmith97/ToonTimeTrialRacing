#pragma once
#include "Common.h"
#include "VertexBufferObject.h"
class CLine
{
public:
	CLine();
	~CLine();
	glm::vec3 Interpolate(glm::vec3& p0, glm::vec3& p1, float t);

	void CreatePath(glm::vec3& p0, glm::vec3& p1);
	void RenderPath();

private:
	GLuint m_vao;
};