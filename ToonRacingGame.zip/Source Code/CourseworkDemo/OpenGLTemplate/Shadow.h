#pragma once
#include "Common.h"
#include "vertexBufferObject.h"
#include "vertexBufferObjectIndexed.h"
#include "Texture.h"
class Shadow
{
public:
	Shadow();
	~Shadow();

	void CreateShadow();
	void RenderShadow();

	void Release();


private:
	float shadowMapWidth;
	float shadowMapHeight;

	GLuint m_fboShadow;
	CVertexBufferObject m_vboShadow;

};
