#include "CatmullRomFirstTrack.h"
#define _USE_MATH_DEFINES
#include <math.h>



CCatmullRomFirstTrack::CCatmullRomFirstTrack()
{
	m_vertexCount = 0;
	m_pipeVertexCount = 0;
	m_rightPipeVertexCount = 0;
	m_leftPipeVertexCount = 0;
}

CCatmullRomFirstTrack::~CCatmullRomFirstTrack()
{
	Release();
}

// Perform Catmull Rom spline interpolation between four points, interpolating the space between p1 and p2
glm::vec3 CCatmullRomFirstTrack::Interpolate(glm::vec3& p0, glm::vec3& p1, glm::vec3& p2, glm::vec3& p3, float t)
{
	float t2 = t * t;
	float t3 = t2 * t;

	glm::vec3 a = p1;
	glm::vec3 b = 0.5f * (-p0 + p2);
	glm::vec3 c = 0.5f * (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3);
	glm::vec3 d = 0.5f * (-p0 + 3.0f * p1 - 3.0f * p2 + p3);

	return a + b * t + c * t2 + d * t3;

}


void CCatmullRomFirstTrack::SetControlPoints()
{
	// Set control points (m_controlPoints) here, or load from disk

	// Optionally, set upvectors (m_controlUpVectors, one for each control point as well)



	/*m_controlPoints.push_back(glm::vec3(100, 10, 0));
	m_controlPoints.push_back(glm::vec3(71, 10, 71));
	m_controlPoints.push_back(glm::vec3(0, 10, 100));
	m_controlPoints.push_back(glm::vec3(-71, 10, 71));
	m_controlPoints.push_back(glm::vec3(-100, 10, 0));
	m_controlPoints.push_back(glm::vec3(-71, 10, -71));
	m_controlPoints.push_back(glm::vec3(0, 10, -100));
	m_controlPoints.push_back(glm::vec3(71, 10, -71));

	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(1, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(1, 0, 0));
	m_controlUpVectors.push_back(glm::vec3(1, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));*/

	// Control points
	m_controlPoints.push_back(glm::vec3(300, 10, 0));
	m_controlPoints.push_back(glm::vec3(271, 10, 71));
	m_controlPoints.push_back(glm::vec3(150, 10, 100));
	m_controlPoints.push_back(glm::vec3(0, 10, 40));
	m_controlPoints.push_back(glm::vec3(-150, 10, 100));

	m_controlPoints.push_back(glm::vec3(-271, 10, 71)); // Angled
	m_controlPoints.push_back(glm::vec3(-300, 10, 0)); /// Angled
	m_controlPoints.push_back(glm::vec3(-271, 10, -71)); // Angled

	m_controlPoints.push_back(glm::vec3(-150, 10, -100));
	m_controlPoints.push_back(glm::vec3(0, 10, -40));
	m_controlPoints.push_back(glm::vec3(150, 10, -100));
	m_controlPoints.push_back(glm::vec3(271, 10, -71));


	//// Up Vectors
	m_controlUpVectors.push_back(glm::vec3(-1, 0, 0));
	m_controlUpVectors.push_back(glm::vec3(-1, 0, -1));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));

	m_controlUpVectors.push_back(glm::vec3(1, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(1, 0, 0));
	m_controlUpVectors.push_back(glm::vec3(1, 1, 0));

	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	m_controlUpVectors.push_back(glm::vec3(-1, 0, 1));

	//const float PI = acos(-1);
	//glm::vec3 vertex;
	//float r = 300;
	//float rStep = (80 - 300) / (100 - 1);
	//float y = 10;
	//float yStep = (10 - 10) / (100 - 1);
	//float a = 6;
	//float aStep = (4 * 2 * PI) / (100 - 1);
	//for (int i = 0; i < 100; ++i)
	//{
	//	vertex.x = r * cos(a);
	//	vertex.z = r * sin(a);
	//	vertex.y = y;
	//	m_controlPoints.push_back(vertex);
	//	// next
	//	r += rStep;
	//	y += yStep;
	//	a += aStep;
	//}

	//for (int i = 0; i < m_controlPoints.size(); i++) {
	//	if (i + 1 < m_controlPoints.size()) {
	//		glm::vec3 pointNext = m_controlPoints[(i + 1)];

	//		glm::vec3 viewDir = glm::normalize(pointNext - m_controlPoints[i]);

	//		glm::vec3 eyeT = viewDir;
	//		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, glm::vec3(0, 1, 0)));
	//		glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));

	//		m_controlUpVectors.push_back(eyeB);
	//	}
	//	m_controlUpVectors.push_back(glm::vec3(0, 1, 0));
	//}

}


// Determine lengths along the control points, which is the set of control points forming the closed curve
void CCatmullRomFirstTrack::ComputeLengthsAlongControlPoints()
{
	int M = (int)m_controlPoints.size();

	float fAccumulatedLength = 0.0f;
	m_distances.push_back(fAccumulatedLength);
	for (int i = 1; i < M; i++) {
		fAccumulatedLength += glm::distance(m_controlPoints[i - 1], m_controlPoints[i]);
		m_distances.push_back(fAccumulatedLength);
	}

	// Get the distance from the last point to the first
	fAccumulatedLength += glm::distance(m_controlPoints[M - 1], m_controlPoints[0]);
	m_distances.push_back(fAccumulatedLength);
}


// Return the point (and upvector, if control upvectors provided) based on a distance d along the control polygon
bool CCatmullRomFirstTrack::Sample(float d, glm::vec3& p, glm::vec3& up)
{
	if (d < 0)
		return false;

	int M = (int)m_controlPoints.size();
	if (M == 0)
		return false;


	float fTotalLength = m_distances[m_distances.size() - 1];

	// The the current length along the control polygon; handle the case where we've looped around the track
	float fLength = d - (int)(d / fTotalLength) * fTotalLength;

	// Find the current segment
	int j = -1;
	for (int i = 0; i < (int)m_distances.size() - 1; i++) {
		if (fLength >= m_distances[i] && fLength < m_distances[i + 1]) {
			j = i; // found it!
			break;
		}
	}

	if (j == -1)
		return false;

	// Interpolate on current segment -- get t
	float fSegmentLength = m_distances[j + 1] - m_distances[j];
	float t = (fLength - m_distances[j]) / fSegmentLength;

	// Get the indices of the four points along the control polygon for the current segment
	int iPrev = ((j - 1) + M) % M;
	int iCur = j;
	int iNext = (j + 1) % M;
	int iNextNext = (j + 2) % M;

	// Interpolate to get the point (and upvector)
	p = Interpolate(m_controlPoints[iPrev], m_controlPoints[iCur], m_controlPoints[iNext], m_controlPoints[iNextNext], t);
	if (m_controlUpVectors.size() == m_controlPoints.size())
		up = glm::normalize(Interpolate(m_controlUpVectors[iPrev], m_controlUpVectors[iCur], m_controlUpVectors[iNext], m_controlUpVectors[iNextNext], t));

	return true;
}



// Sample a set of control points using an open Catmull-Rom spline, to produce a set of iNumSamples that are (roughly) equally spaced
void CCatmullRomFirstTrack::UniformlySampleControlPoints(int numSamples)
{
	glm::vec3 p, up;

	// Compute the lengths of each segment along the control polygon, and the total length
	ComputeLengthsAlongControlPoints();
	float fTotalLength = m_distances[m_distances.size() - 1];

	// The spacing will be based on the control polygon
	float fSpacing = fTotalLength / numSamples;

	// Call PointAt to sample the spline, to generate the points
	for (int i = 0; i < numSamples; i++) {
		Sample(i * fSpacing, p, up);
		m_centrelinePoints.push_back(p);
		if (m_controlUpVectors.size() > 0)
			m_centrelineUpVectors.push_back(up);

	}


	// Repeat once more for truly equidistant points
	m_controlPoints = m_centrelinePoints;
	m_controlUpVectors = m_centrelineUpVectors;
	m_centrelinePoints.clear();
	m_centrelineUpVectors.clear();
	m_distances.clear();
	ComputeLengthsAlongControlPoints();
	fTotalLength = m_distances[m_distances.size() - 1];
	fSpacing = fTotalLength / numSamples;
	for (int i = 0; i < numSamples; i++) {
		Sample(i * fSpacing, p, up);
		m_centrelinePoints.push_back(p);
		if (m_controlUpVectors.size() > 0)
			m_centrelineUpVectors.push_back(up);
	}

	// Calculate left pipe centerline
	glm::vec3 pointNext;
	for (int i = 0; i < m_centrelinePoints.size(); i++) {

		pointNext = m_centrelinePoints[(i + 1) % m_centrelinePoints.size()];

		glm::vec3 viewDir = glm::normalize(pointNext - m_centrelinePoints[i]);

		glm::vec3 eyeT = viewDir;
		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, m_centrelineUpVectors[i]));

		glm::vec3 offset = 7.5f * eyeN;
		glm::vec3 left_centrelinePoint = m_centrelinePoints[i] - offset;
		glm::vec3 right_centrelinePoint = m_centrelinePoints[i] + offset;

		m_leftCentreLinePoints.push_back(left_centrelinePoint);
		m_rightCentreLinePoints.push_back(right_centrelinePoint);
	}


}




void CCatmullRomFirstTrack::CreateCentreline()
{
	// Call Set Control Points
	SetControlPoints();

	// Call UniformlySampleControlPoints with the number of samples required
	UniformlySampleControlPoints(num_ctrl_pts);

	// Create a VAO called m_vaoCentreline and a VBO to get the points onto the graphics card
	glGenVertexArrays(1, &m_vaoCentreline);
	glBindVertexArray(m_vaoCentreline);
	// Create a VBO
	m_vboCL.Create();
	m_vboCL.Bind();
	glm::vec2 texCoord(0.0f, 0.0f);
	for (unsigned int i = 0; i < m_centrelinePoints.size(); i++) {
		m_vboCL.AddData(&m_centrelinePoints[i], sizeof(glm::vec3));
		m_vboCL.AddData(&texCoord, sizeof(glm::vec2));
		m_vboCL.AddData(&m_centrelineUpVectors[i], sizeof(glm::vec3));
	}
	// Upload the VBO to the GPU
	m_vboCL.UploadDataToGPU(GL_STATIC_DRAW);
	// Set the vertex attribute locations
	GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
		+ sizeof(glm::vec2)));
}

// Based on code by Song Ho Ahn, downloadable from http://www.songho.ca/opengl/gl_cylinder.html
std::vector<glm::vec3> CCatmullRomFirstTrack::buildCircle(float radius, int steps, int type)
{
	std::vector<glm::vec3> points;
	if (steps < 2) return points;

	float PI;
	if (type == 0) {
		PI = acos(-1) /** 2.0f*/;
	}

	else if (type == 1) {
		PI = -acos(-1);
	}

	float x, y, a;
	for (int i = 0; i <= steps / 2; ++i)
	{
		a = PI / (steps / 2) * i;
		x = radius * cosf(a);
		y = radius * sinf(a);
		points.push_back(glm::vec3(x, y, 0));
	}
	return points;
}

// Based on code by Song Ho Ahn, downloadable from http://www.songho.ca/opengl/gl_cylinder.html
void CCatmullRomFirstTrack::FindPipePoints(glm::vec3 eyeB, vector<glm::vec3> circle, vector<glm::vec3> circle2,
	glm::vec3 eyeN, float trackDistance) {
	// For each point on the half circle, calculate its position relative to point i on the track
	for (int c = 0; c < circle.size(); c++) {
		// If this is the first time claclulating this point on the half circle
		int circle_index = m_pipeCurvePoints.size() - 1;
		if (c > circle_index) {
			vector<glm::vec3> new_curve;
			m_pipeCurvePoints.push_back(new_curve);
			m_leftPipeCurvePoints.push_back(new_curve);
			m_rightPipeCurvePoints.push_back(new_curve);
			m_pipeCurveNormals.push_back(new_curve);
			m_rightPipeCurveNormals.push_back(new_curve);
			m_leftPipeCurveNormals.push_back(new_curve);
		}
		glm::vec4 circle_point;
		glm::vec4 left_circle_point;
		glm::vec4 right_circle_point;
		glm::vec3 new_circle_point;
		glm::vec3 new_left_circle_point;
		glm::vec3 new_right_circle_point;

		// Rotate the circle point by the angle the B vector is from the y Axis
		circle_point = glm::vec4(circle[c], 1.f);
		left_circle_point = glm::vec4(circle2[c], 1.f);
		right_circle_point = glm::vec4(circle2[c], 1.f);
		glm::mat4 rot_matrix = glm::mat4(1.f);
		glm::mat4 rot_left_matrix = glm::mat4(1.f);
		glm::mat4 rot_right_matrix = glm::mat4(1.f);
		float PI = -acos(-1);
		float rot_angle = acos(glm::dot(eyeB, glm::vec3(0, 1, 0)));
		rot_matrix = glm::rotate(rot_matrix, -rot_angle, glm::vec3(0, 0, 1));
		rot_left_matrix = glm::rotate(rot_left_matrix, -rot_angle, glm::vec3(0, 0, 1));
		rot_right_matrix = glm::rotate(rot_right_matrix, -rot_angle, glm::vec3(0, 0, 1));

		circle_point = rot_matrix * circle_point;
		left_circle_point = rot_left_matrix * left_circle_point;
		right_circle_point = rot_right_matrix * right_circle_point;

		// Translate the circle point to the first point on the track
		glm::mat4 translation_matrix = glm::mat4(1.f);
		glm::mat4 left_translation_matrix = glm::mat4(1.f);
		glm::mat4 right_translation_matrix = glm::mat4(1.f);

		translation_matrix = glm::translate(translation_matrix, m_centrelinePoints[0]);
		left_translation_matrix = glm::translate(left_translation_matrix, m_leftCentreLinePoints[0]);
		right_translation_matrix = glm::translate(right_translation_matrix, m_rightCentreLinePoints[0]);

		circle_point = translation_matrix * circle_point;
		new_circle_point = glm::vec3(circle_point);

		left_circle_point = left_translation_matrix * left_circle_point;
		new_left_circle_point = glm::vec3(left_circle_point);

		right_circle_point = right_translation_matrix * right_circle_point;
		new_right_circle_point = glm::vec3(right_circle_point);

		// Now project this curve up the track onto each point's plane until it reaches the desired distance
		glm::vec3 pointNext;
		glm::vec3 pointNextNext;

		glm::vec3 leftPointNext;
		glm::vec3 leftPointNextNext;

		glm::vec3 rightPointNext;
		glm::vec3 rightPointNextNext;

		glm::vec3 last_circle_point = new_circle_point;
		glm::vec3 last_left_circle_point = new_left_circle_point;
		glm::vec3 last_right_circle_point = new_right_circle_point;

		for (int future_i = 0; future_i < trackDistance; future_i++) {
			pointNext = m_centrelinePoints[(future_i + 1) % m_centrelinePoints.size()];
			pointNextNext = m_centrelinePoints[(future_i + 2) % m_centrelinePoints.size()];

			leftPointNext = m_leftCentreLinePoints[(future_i + 1) % m_leftCentreLinePoints.size()];
			leftPointNextNext = m_leftCentreLinePoints[(future_i + 2) % m_leftCentreLinePoints.size()];

			rightPointNext = m_rightCentreLinePoints[(future_i + 1) % m_rightCentreLinePoints.size()];
			rightPointNextNext = m_rightCentreLinePoints[(future_i + 2) % m_rightCentreLinePoints.size()];

			glm::vec3 f_viewDir = glm::normalize(pointNext - m_centrelinePoints[future_i]);
			glm::vec3 f_leftViewDir = glm::normalize(leftPointNext - m_leftCentreLinePoints[future_i]);
			glm::vec3 f_rightViewDir = glm::normalize(rightPointNext - m_rightCentreLinePoints[future_i]);

			glm::vec3 f_eyeT = f_viewDir;
			glm::vec3 f_leftEyeT = f_leftViewDir;
			glm::vec3 f_rightEyeT = f_rightViewDir;

			glm::vec3 f_eyeN = glm::normalize(glm::cross(f_eyeT, m_centrelineUpVectors[future_i]));
			glm::vec3 f_leftEyeN = glm::normalize(glm::cross(f_leftEyeT, m_centrelineUpVectors[future_i]));
			glm::vec3 f_rightEyeN = glm::normalize(glm::cross(f_rightEyeT, m_centrelineUpVectors[future_i]));

			glm::vec3 f_eyeB = glm::normalize(glm::cross(f_eyeT, f_eyeN));
			glm::vec3 f_leftEyeB = glm::normalize(glm::cross(f_leftEyeT, f_leftEyeN));
			glm::vec3 f_rightEyeB = glm::normalize(glm::cross(f_rightEyeT, f_rightEyeN));


			glm::vec3 otherDir = pointNextNext - pointNext;
			glm::vec3 leftOtherDir = leftPointNextNext - leftPointNext;
			glm::vec3 rightOtherDir = rightPointNextNext - rightPointNext;


			glm::vec3 planeNormal = f_viewDir + otherDir;
			glm::vec3 leftPlaneNormal = f_leftViewDir + leftOtherDir;
			glm::vec3 rightPlaneNormal = f_rightViewDir + rightOtherDir;


			float circle_plane_d = -glm::dot(planeNormal, pointNext);
			float left_circle_plane_d = -glm::dot(leftPlaneNormal, leftPointNext);
			float right_circle_plane_d = -glm::dot(rightPlaneNormal, rightPointNext);

			float dot1 = glm::dot(planeNormal, last_circle_point);
			float dot2 = glm::dot(planeNormal, f_viewDir);

			float leftDot1 = glm::dot(leftPlaneNormal, last_left_circle_point);
			float leftDot2 = glm::dot(leftPlaneNormal, f_leftViewDir);

			float rightDot1 = glm::dot(rightPlaneNormal, last_right_circle_point);
			float rightDot2 = glm::dot(rightPlaneNormal, f_rightViewDir);

			float t = -(dot1 + circle_plane_d) / dot2;
			float left_t = -(leftDot1 + left_circle_plane_d) / leftDot2;
			float right_t = -(rightDot1 + right_circle_plane_d) / rightDot2;


			new_circle_point = last_circle_point + (f_viewDir * t);
			new_left_circle_point = last_left_circle_point + (f_leftViewDir * left_t);
			new_right_circle_point = last_right_circle_point + (f_rightViewDir * right_t);

			last_circle_point = new_circle_point;
			last_left_circle_point = new_left_circle_point;
			last_right_circle_point = new_right_circle_point;

		}

		m_pipeCurvePoints[c].push_back(new_circle_point);
		m_leftPipeCurvePoints[c].push_back(new_left_circle_point);
		m_rightPipeCurvePoints[c].push_back(new_right_circle_point);

		m_pipeCurveNormals[c].push_back(glm::normalize(new_circle_point - m_centrelinePoints[trackDistance]));
		m_rightPipeCurveNormals[c].push_back(glm::normalize(new_right_circle_point -
			m_rightCentreLinePoints[trackDistance]));
		m_leftPipeCurveNormals[c].push_back(glm::normalize(new_left_circle_point -
			m_leftCentreLinePoints[trackDistance]));

	}
}


void CCatmullRomFirstTrack::CreateOffsetCurves()
{
	// Compute the offset curves, one left, and one right.  Store the points in m_leftOffsetPoints and m_rightOffsetPoints respectively

	// Generate two VAOs called m_vaoLeftOffsetCurve and m_vaoRightOffsetCurve, each with a VBO, and get the offset curve points on the graphics card
	// Note it is possible to only use one VAO / VBO with all the points instead.

	glGenVertexArrays(1, &m_vaoLeftOffsetCurve);
	glBindVertexArray(m_vaoLeftOffsetCurve);

	m_vboLOC.Create();
	m_vboLOC.Bind();


	glm::vec2 texCoord(0.0f, 0.0f);
	//glm::vec3 normal(0.0f, 1.0f, 0.0f);

	std::vector<glm::vec3> circle = buildCircle(10.f, 60, 0);
	std::vector<glm::vec3> circle2 = buildCircle(2.5f, 60, 1);


	glm::vec3 pointNext;

	for (unsigned int i = 0; i < m_centrelinePoints.size(); i++) {

		pointNext = m_centrelinePoints[(i + 1) % m_centrelinePoints.size()];


		glm::vec3 viewDir = glm::normalize(pointNext - m_centrelinePoints[i]);

		glm::vec3 eyeT = viewDir;
		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, m_centrelineUpVectors[i]));
		glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));
		glm::vec3 offset = (width / 2.f) * eyeN;
		glm::vec3 lBorder = m_centrelinePoints[i] - offset;


		// Calculate the pipe points at this centreline point
		FindPipePoints(eyeB, circle, circle2, eyeN, i);

		m_leftOffsetPoints.push_back(lBorder);


		m_vboLOC.AddData(&lBorder, sizeof(glm::vec3));
		m_vboLOC.AddData(&texCoord, sizeof(glm::vec2));
		m_vboLOC.AddData(&m_centrelineUpVectors[i], sizeof(glm::vec3));
	}

	m_vboLOC.UploadDataToGPU(GL_STATIC_DRAW);
	// Set the vertex attribute locations
	GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
		+ sizeof(glm::vec2)));

	glGenVertexArrays(1, &m_vaoRightOffsetCurve);
	glBindVertexArray(m_vaoRightOffsetCurve);


	m_vboROC.Create();
	m_vboROC.Bind();

	for (unsigned int i = 0; i < m_centrelinePoints.size(); i++) {

		if (i + 1 >= m_centrelinePoints.size()) {
			pointNext = m_centrelinePoints[0];
		}

		else {
			pointNext = m_centrelinePoints[i + 1];
		}

		glm::vec3 viewDir = glm::normalize(pointNext - m_centrelinePoints[i]);

		glm::vec3 eyeT = viewDir;
		glm::vec3 eyeN = glm::normalize(glm::cross(eyeT, m_centrelineUpVectors[i]));
		glm::vec3 eyeB = glm::normalize(glm::cross(eyeT, eyeN));
		glm::vec3 offset = (width / 2.f) * eyeN;
		glm::vec3 og_vec = m_centrelinePoints[i];
		glm::vec3 rBorder = m_centrelinePoints[i] + offset;

		m_rightOffsetPoints.push_back(rBorder);

		m_vboROC.AddData(&rBorder, sizeof(glm::vec3));
		m_vboROC.AddData(&texCoord, sizeof(glm::vec2));
		m_vboROC.AddData(&m_centrelineUpVectors[i], sizeof(glm::vec3));
	}

	m_vboROC.UploadDataToGPU(GL_STATIC_DRAW);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
		+ sizeof(glm::vec2)));
}


void CCatmullRomFirstTrack::CreateTrack(string filename)
{

	// Generate a VAO called m_vaoTrack and a VBO to get the offset curve points and indices on the graphics card

	m_texture.Load(filename);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_S, GL_REPEAT);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_T, GL_REPEAT);

	glGenVertexArrays(1, &m_vaoTrack);
	glBindVertexArray(m_vaoTrack);

	m_vboT.Create();
	m_vboT.Bind();

	std::vector<glm::vec2> texture_vec = { glm::vec2(0, 0) , glm::vec2(1, 0) , glm::vec2(0, 1) , glm::vec2(1, 1) };
	//glm::vec2 texCoord(0.0f, 0.0f);
	//glm::vec3 normal(0.0f, 1.0f, 0.0f);
	float tex_face = 1;
	float tex_perc = 0.1;
	float base_y = 0.f;
	float top_y;

	for (int i = 0; i < m_leftOffsetPoints.size(); i++) {
		top_y = tex_face * tex_perc;
		glm::vec2 debug_tex = glm::vec2(texture_vec[0].x, texture_vec[0].y + base_y);

		m_vboT.AddData(&m_leftOffsetPoints[i], sizeof(glm::vec3));
		m_vboT.AddData(&debug_tex, sizeof(glm::vec2));
		m_vboT.AddData(&m_centrelineUpVectors[i], sizeof(glm::vec3));
		m_vertexCount += 1;

		debug_tex = glm::vec2(texture_vec[1].x, texture_vec[1].y + base_y);
		m_vboT.AddData(&m_rightOffsetPoints[i], sizeof(glm::vec3));
		m_vboT.AddData(&debug_tex, sizeof(glm::vec2));
		m_vboT.AddData(&m_centrelineUpVectors[i], sizeof(glm::vec3));
		m_vertexCount += 1;

		debug_tex = glm::vec2(texture_vec[2].x, texture_vec[2].y * top_y);
		m_vboT.AddData(&m_leftOffsetPoints[(i + 1) % m_leftOffsetPoints.size()], sizeof(glm::vec3));
		m_vboT.AddData(&debug_tex, sizeof(glm::vec2));
		m_vboT.AddData(&m_centrelineUpVectors[(i + 1) % m_leftOffsetPoints.size()], sizeof(glm::vec3));
		m_vertexCount += 1;

		debug_tex = glm::vec2(texture_vec[3].x, texture_vec[3].y * top_y);
		m_vboT.AddData(&m_rightOffsetPoints[(i + 1) % m_rightOffsetPoints.size()], sizeof(glm::vec3));
		m_vboT.AddData(&debug_tex, sizeof(glm::vec2));
		m_vboT.AddData(&m_centrelineUpVectors[(i + 1) % m_rightOffsetPoints.size()], sizeof(glm::vec3));
		m_vertexCount += 1;

		tex_face += 1.f;
		base_y = top_y;

		if (tex_face * tex_perc > 1.f) {
			tex_face = 1.f;
			base_y = 0.f;
		}
	}

	m_vboT.UploadDataToGPU(GL_STATIC_DRAW);
	// Set the vertex attribute locations
	GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
		+ sizeof(glm::vec2)));
}


void CCatmullRomFirstTrack::CreatePipePoints() {
	// Create a VAO called m_vaoCentreline and a VBO to get the points onto the graphics card
	for (int c = 0; c < m_pipeCurvePoints.size(); c++) {
		GLuint new_vao;
		m_vaoPipeVector.push_back(new_vao);

		glGenVertexArrays(1, &m_vaoPipeVector[c]);
		glBindVertexArray(m_vaoPipeVector[c]);


		// Create a VBO
		CVertexBufferObject new_vbo;
		m_vboPipeVector.push_back(new_vbo);

		m_vboPipeVector[c].Create();
		m_vboPipeVector[c].Bind();
		glm::vec2 texCoord(0.0f, 0.0f);
		//glm::vec3 normal(0.0f, 1.0f, 0.0f);
		for (unsigned int i = 0; i < m_pipeCurvePoints[c].size(); i++) {
			m_vboPipeVector[c].AddData(&m_pipeCurvePoints[c][i], sizeof(glm::vec3));
			m_vboPipeVector[c].AddData(&texCoord, sizeof(glm::vec2));
			m_vboPipeVector[c].AddData(&m_pipeCurveNormals[c][i], sizeof(glm::vec3));
		}
		// Upload the VBO to the GPU
		m_vboPipeVector[c].UploadDataToGPU(GL_STATIC_DRAW);
		// Set the vertex attribute locations
		GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
		// Vertex positions
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
		// Texture coordinates
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
		// Normal vectors
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
			+ sizeof(glm::vec2)));
	}


	for (int c = 0; c < m_leftPipeCurvePoints.size(); c++) {
		GLuint new_left_vao;;
		m_vaoLeftPipeVector.push_back(new_left_vao);

		glGenVertexArrays(1, &m_vaoLeftPipeVector[c]);
		glBindVertexArray(m_vaoLeftPipeVector[c]);

		// Create a VBO
		CVertexBufferObject new_left_vbo;
		m_vboLeftPipeVector.push_back(new_left_vbo);

		m_vboLeftPipeVector[c].Create();
		m_vboLeftPipeVector[c].Bind();
		glm::vec2 texCoord(0.0f, 0.0f);
		//glm::vec3 normal(0.0f, 1.0f, 0.0f);
		for (unsigned int i = 0; i < m_leftPipeCurvePoints[c].size(); i++) {
			m_vboLeftPipeVector[c].AddData(&m_leftPipeCurvePoints[c][i], sizeof(glm::vec3));
			m_vboLeftPipeVector[c].AddData(&texCoord, sizeof(glm::vec2));
			m_vboLeftPipeVector[c].AddData(&m_leftPipeCurveNormals[c][i], sizeof(glm::vec3));
		}
		// Upload the VBO to the GPU

		m_vboLeftPipeVector[c].UploadDataToGPU(GL_STATIC_DRAW);
		// Set the vertex attribute locations
		GLsizei leftStride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
		// Vertex positions
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, leftStride, 0);
		// Texture coordinates
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, leftStride, (void*)sizeof(glm::vec3));
		// Normal vectors
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, leftStride, (void*)(sizeof(glm::vec3)
			+ sizeof(glm::vec2)));
	}

	for (int c = 0; c < m_rightPipeCurvePoints.size(); c++) {
		GLuint new_right_vao;;
		m_vaoRightPipeVector.push_back(new_right_vao);

		glGenVertexArrays(1, &m_vaoRightPipeVector[c]);
		glBindVertexArray(m_vaoRightPipeVector[c]);

		// Create a VBO
		CVertexBufferObject new_right_vbo;
		m_vboRightPipeVector.push_back(new_right_vbo);

		m_vboRightPipeVector[c].Create();
		m_vboRightPipeVector[c].Bind();
		glm::vec2 texCoord(0.0f, 0.0f);
		//glm::vec3 normal(0.0f, 1.0f, 0.0f);
		for (unsigned int i = 0; i < m_rightPipeCurvePoints[c].size(); i++) {
			m_vboRightPipeVector[c].AddData(&m_rightPipeCurvePoints[c][i], sizeof(glm::vec3));
			m_vboRightPipeVector[c].AddData(&texCoord, sizeof(glm::vec2));
			m_vboRightPipeVector[c].AddData(&m_rightPipeCurveNormals[c][i], sizeof(glm::vec3));
		}
		// Upload the VBO to the GPU

		m_vboRightPipeVector[c].UploadDataToGPU(GL_STATIC_DRAW);
		// Set the vertex attribute locations
		GLsizei rightStride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
		// Vertex positions
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, rightStride, 0);
		// Texture coordinates
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, rightStride, (void*)sizeof(glm::vec3));
		// Normal vectors
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, rightStride, (void*)(sizeof(glm::vec3)
			+ sizeof(glm::vec2)));
	}
}

void CCatmullRomFirstTrack::CreateRightLeftPipeSurface(string filename)
{
	// Generate a VAO called m_vaoTrack and a VBO to get the offset curve points and indices on the graphics card

	m_pipeRightLeftTexture.Load(filename);
	m_pipeRightLeftTexture.SetSamplerObjectParameter(GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);
	m_pipeRightLeftTexture.SetSamplerObjectParameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	m_pipeRightLeftTexture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_S, GL_REPEAT);
	m_pipeRightLeftTexture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_T, GL_REPEAT);

	vector< GLuint*> vaoRightLeftVector;
	vaoRightLeftVector.push_back(&m_vaoRightPipeSurface);
	vaoRightLeftVector.push_back(&m_vaoLeftPipeSurface);

	vector<CVertexBufferObject*> vboRightLeftVector;
	vboRightLeftVector.push_back(&m_vboRightPipeSurface);
	vboRightLeftVector.push_back(&m_vboRightPipeSurface);

	vector<vector<vector<glm::vec3>>> pointsRightLeftVector;
	pointsRightLeftVector.push_back(m_rightPipeCurvePoints);
	pointsRightLeftVector.push_back(m_leftPipeCurvePoints);

	vector<unsigned int*> countRightLeftVector;
	countRightLeftVector.push_back(&m_rightPipeVertexCount);
	countRightLeftVector.push_back(&m_leftPipeVertexCount);

	vector<vector<vector<glm::vec3>>> normalsRightLeftVector;
	normalsRightLeftVector.push_back(m_rightPipeCurveNormals);
	normalsRightLeftVector.push_back(m_leftPipeCurveNormals);

	for (int v = 0; v < 2; v++) {
		glGenVertexArrays(1, vaoRightLeftVector[v]);
		glBindVertexArray(*vaoRightLeftVector[v]);

		(*vboRightLeftVector[v]).Create();
		(*vboRightLeftVector[v]).Bind();

		std::vector<glm::vec2> texture_vec = { glm::vec2(0, 0) , glm::vec2(1, 0) , glm::vec2(0, 1) , glm::vec2(1, 1) };

		float tex_y_face = 1;
		float tex_y_perc = 0.1f;
		float tex_x_face = 1;
		float tex_x_perc = 1.f / (pointsRightLeftVector[v].size() + 1);
		float base_y = 0.f;
		float base_x = 0.f;
		float top_y;
		float top_x;

		for (int i = pointsRightLeftVector[v].size(); i > 0; i--) {
			for (int c = 0; c < m_rightCentreLinePoints.size(); c++) {
				top_y = tex_y_face * tex_y_perc;
				top_x = tex_x_face * tex_x_perc;

				glm::vec3 v0;
				glm::vec3 v1;
				glm::vec3 v2;
				glm::vec3 v3;

				glm::vec3 n0;
				glm::vec3 n1;
				glm::vec3 n2;
				glm::vec3 n3;

				if (i == pointsRightLeftVector[v].size()) {

					n0 = m_centrelineUpVectors[c];
					n1 = normalsRightLeftVector[v][pointsRightLeftVector[v].size() - 1][c];
					n2 = m_centrelineUpVectors[(c + 1) % m_rightCentreLinePoints.size()];
					n3 = normalsRightLeftVector[v][pointsRightLeftVector[v].size() - 1]
						[(c + 1) % m_rightCentreLinePoints.size()];

					if (v == 0) {
						v0 = m_rightOffsetPoints[c];
						v1 = pointsRightLeftVector[v][pointsRightLeftVector[v].size() - 1][c];
						v2 = m_rightOffsetPoints[(c + 1) % m_rightCentreLinePoints.size()];
						v3 = pointsRightLeftVector[v][pointsRightLeftVector[v].size() - 1]
							[(c + 1) % m_rightCentreLinePoints.size()];
					}

					else {
						v0 = pointsRightLeftVector[v][0][c];
						v1 = m_leftOffsetPoints[c];
						v2 = pointsRightLeftVector[v][0][(c + 1) % m_rightCentreLinePoints.size()];
						v3 = m_leftOffsetPoints[(c + 1) % m_rightCentreLinePoints.size()];
					}
				}

				else {
					v0 = pointsRightLeftVector[v][i][c];
					v1 = pointsRightLeftVector[v][i - 1][c];
					v2 = pointsRightLeftVector[v][i][(c + 1) % m_rightCentreLinePoints.size()];
					v3 = pointsRightLeftVector[v][i - 1][(c + 1) % m_rightCentreLinePoints.size()];

					n0 = normalsRightLeftVector[v][i][c];
					n1 = normalsRightLeftVector[v][i - 1][c];
					n2 = normalsRightLeftVector[v][i][(c + 1) % m_rightCentreLinePoints.size()];
					n3 = normalsRightLeftVector[v][i - 1][(c + 1) % m_rightCentreLinePoints.size()];
				}



				glm::vec2 debug_tex = glm::vec2(texture_vec[0].x + base_x, texture_vec[0].y + base_y);
				(*vboRightLeftVector[v]).AddData(&v0, sizeof(glm::vec3));
				(*vboRightLeftVector[v]).AddData(&debug_tex, sizeof(glm::vec2));
				(*vboRightLeftVector[v]).AddData(&n0, sizeof(glm::vec3));
				*countRightLeftVector[v] += 1;

				debug_tex = glm::vec2(texture_vec[1].x * top_x, texture_vec[1].y + base_y);
				(*vboRightLeftVector[v]).AddData(&v1, sizeof(glm::vec3));
				(*vboRightLeftVector[v]).AddData(&debug_tex, sizeof(glm::vec2));
				(*vboRightLeftVector[v]).AddData(&n1, sizeof(glm::vec3));
				*countRightLeftVector[v] += 1;

				debug_tex = glm::vec2(texture_vec[2].x + base_x, texture_vec[2].y * top_y);
				(*vboRightLeftVector[v]).AddData(&v2, sizeof(glm::vec3));
				(*vboRightLeftVector[v]).AddData(&debug_tex, sizeof(glm::vec2));
				(*vboRightLeftVector[v]).AddData(&n2, sizeof(glm::vec3));
				*countRightLeftVector[v] += 1;

				debug_tex = glm::vec2(texture_vec[3].x * top_x, texture_vec[3].y * top_y);
				(*vboRightLeftVector[v]).AddData(&v3, sizeof(glm::vec3));
				(*vboRightLeftVector[v]).AddData(&debug_tex, sizeof(glm::vec2));
				(*vboRightLeftVector[v]).AddData(&n3, sizeof(glm::vec3));
				*countRightLeftVector[v] += 1;

				tex_y_face += 1.f;
				base_y = top_y;

				if (tex_y_face * tex_y_perc > 1.f) {
					tex_y_face = 1.f;
					base_y = 0.f;
				}
			}

			tex_x_face += 1.f;
			base_x = top_x;

			if (tex_x_face * tex_x_perc > 1.f) {
				tex_x_face = 1.f;
				base_x = 0.f;
			}
		}

		(*vboRightLeftVector[v]).UploadDataToGPU(GL_STATIC_DRAW);
		// Set the vertex attribute locations
		GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
		// Vertex positions
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
		// Texture coordinates
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
		// Normal vectors
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
			+ sizeof(glm::vec2)));
	}
}

void CCatmullRomFirstTrack::CreateBasePipeSurface(string filename) {
	// Generate a VAO called m_vaoTrack and a VBO to get the offset curve points and indices on the graphics card

	m_pipeTexture.Load(filename);
	m_pipeTexture.SetSamplerObjectParameter(GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);
	m_pipeTexture.SetSamplerObjectParameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	m_pipeTexture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_S, GL_REPEAT);
	m_pipeTexture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_T, GL_REPEAT);

	glGenVertexArrays(1, &m_vaoPipeSurface);
	glBindVertexArray(m_vaoPipeSurface);

	m_vboPipeSurface.Create();
	m_vboPipeSurface.Bind();

	std::vector<glm::vec2> texture_vec = { glm::vec2(0, 0) , glm::vec2(1, 0) , glm::vec2(0, 1) , glm::vec2(1, 1) };

	float tex_y_face = 1;
	float tex_y_perc = 0.1f;
	float tex_x_face = 1;
	float tex_x_perc = 1.f / (m_pipeCurvePoints.size() + 1);
	float base_y = 0.f;
	float base_x = 0.f;
	float top_y;
	float top_x;



	for (int i = -1; i + 1 < m_pipeCurvePoints.size() + 1; i++) {
		for (int c = 0; c < m_centrelinePoints.size(); c++) {
			top_y = tex_y_face * tex_y_perc;
			top_x = tex_x_face * tex_x_perc;

			glm::vec3 v0;
			glm::vec3 v1;
			glm::vec3 v2;
			glm::vec3 v3;

			glm::vec3 n0;
			glm::vec3 n1;
			glm::vec3 n2;
			glm::vec3 n3;


			if (i == -1) {
				v0 = m_rightPipeCurvePoints[0][c];
				v1 = m_pipeCurvePoints[0][c];
				v2 = m_rightPipeCurvePoints[0][(c + 1) % m_rightCentreLinePoints.size()];
				v3 = m_pipeCurvePoints[0][(c + 1) % m_rightCentreLinePoints.size()];

				n0 = m_rightPipeCurveNormals[0][c];
				n1 = m_pipeCurveNormals[0][c];
				n2 = m_rightPipeCurveNormals[0][(c + 1) % m_rightCentreLinePoints.size()];
				n3 = m_pipeCurveNormals[0][(c + 1) % m_rightCentreLinePoints.size()];
			}

			else if (i == m_pipeCurvePoints.size() - 1) {
				v0 = m_pipeCurvePoints[m_pipeCurvePoints.size() - 1][c];
				v1 = m_leftPipeCurvePoints[m_leftPipeCurvePoints.size() - 1][c];
				v2 = m_pipeCurvePoints[m_pipeCurvePoints.size() - 1]
					[(c + 1) % m_rightCentreLinePoints.size()];
				v3 = m_leftPipeCurvePoints[m_leftPipeCurvePoints.size() - 1]
					[(c + 1) % m_rightCentreLinePoints.size()];

				n0 = m_pipeCurveNormals[m_pipeCurvePoints.size() - 1][c];
				n1 = m_leftPipeCurveNormals[m_leftPipeCurvePoints.size() - 1][c];
				n2 = m_pipeCurveNormals[m_pipeCurvePoints.size() - 1]
					[(c + 1) % m_rightCentreLinePoints.size()];
				n3 = m_leftPipeCurveNormals[m_leftPipeCurvePoints.size() - 1][(c + 1) % m_rightCentreLinePoints.size()];
			}

			else {
				v0 = m_pipeCurvePoints[i][c];
				v1 = m_pipeCurvePoints[i + 1][c];
				v2 = m_pipeCurvePoints[i][(c + 1) % m_rightCentreLinePoints.size()];
				v3 = m_pipeCurvePoints[i + 1][(c + 1) % m_rightCentreLinePoints.size()];

				n0 = m_pipeCurveNormals[i][c];
				n1 = m_pipeCurveNormals[i + 1][c];
				n2 = m_pipeCurveNormals[i][(c + 1) % m_rightCentreLinePoints.size()];
				n3 = m_pipeCurveNormals[i + 1][(c + 1) % m_rightCentreLinePoints.size()];
			}

			glm::vec2 debug_tex = glm::vec2(texture_vec[0].x + base_x, texture_vec[0].y + base_y);
			m_vboPipeSurface.AddData(&v0, sizeof(glm::vec3));
			m_vboPipeSurface.AddData(&debug_tex, sizeof(glm::vec2));
			m_vboPipeSurface.AddData(&n0, sizeof(glm::vec3));
			m_pipeVertexCount += 1;

			debug_tex = glm::vec2(texture_vec[1].x * top_x, texture_vec[1].y + base_y);
			m_vboPipeSurface.AddData(&v1, sizeof(glm::vec3));
			m_vboPipeSurface.AddData(&debug_tex, sizeof(glm::vec2));
			m_vboPipeSurface.AddData(&n1, sizeof(glm::vec3));
			m_pipeVertexCount += 1;

			debug_tex = glm::vec2(texture_vec[2].x + base_x, texture_vec[2].y * top_y);
			m_vboPipeSurface.AddData(&v2, sizeof(glm::vec3));
			m_vboPipeSurface.AddData(&debug_tex, sizeof(glm::vec2));
			m_vboPipeSurface.AddData(&n2, sizeof(glm::vec3));
			m_pipeVertexCount += 1;

			debug_tex = glm::vec2(texture_vec[3].x * top_x, texture_vec[3].y * top_y);
			m_vboPipeSurface.AddData(&v3, sizeof(glm::vec3));
			m_vboPipeSurface.AddData(&debug_tex, sizeof(glm::vec2));
			m_vboPipeSurface.AddData(&n3, sizeof(glm::vec3));
			m_pipeVertexCount += 1;

			tex_y_face += 1.f;
			base_y = top_y;

			if (tex_y_face * tex_y_perc > 1.f) {
				tex_y_face = 1.f;
				base_y = 0.f;
			}
		}

		tex_x_face += 1.f;
		base_x = top_x;

		if (tex_x_face * tex_x_perc > 1.f) {
			tex_x_face = 1.f;
			base_x = 0.f;
		}
	}

	m_vboPipeSurface.UploadDataToGPU(GL_STATIC_DRAW);
	// Set the vertex attribute locations
	GLsizei stride = 2 * sizeof(glm::vec3) + sizeof(glm::vec2);
	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
	// Texture coordinates
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)sizeof(glm::vec3));
	// Normal vectors
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(glm::vec3)
		+ sizeof(glm::vec2)));

}


void CCatmullRomFirstTrack::RenderCentreline()
{
	// Bind the VAO m_vaoCentreline and render it
	glBindVertexArray(m_vaoCentreline);

	glLineWidth(6.f);
	glPointSize(5.f);
	glDrawArrays(GL_LINES, 0, m_centrelinePoints.size());
	glDrawArrays(GL_POINTS, 0, m_centrelinePoints.size());

}

void CCatmullRomFirstTrack::RenderOffsetCurves()
{
	glPointSize(8.f);
	// Bind the VAO m_vaoLeftOffsetCurve and render it
	glBindVertexArray(m_vaoLeftOffsetCurve);
	glDrawArrays(GL_LINE, 0, m_centrelinePoints.size());
	//glDrawArrays(GL_POINTS, 0, m_centrelinePoints.size());

	// Bind the VAO m_vaoRightOffsetCurve and render it

	glPointSize(3.f);
	glBindVertexArray(m_vaoRightOffsetCurve);
	glDrawArrays(GL_LINE, 0, m_centrelinePoints.size());
	//glDrawArrays(GL_POINTS, 0, m_centrelinePoints.size());
}


void CCatmullRomFirstTrack::RenderTrack()
{
	/*glLineWidth(2.f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glDisable(GL_CULL_FACE);*/

	// Bind the VAO m_vaoTrack and render it
	glBindVertexArray(m_vaoTrack);
	m_texture.Bind();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_vertexCount);
	/*glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_CULL_FACE);*/
}

void CCatmullRomFirstTrack::RenderPipePoints() {
	for (int c = 0; c < m_pipeCurvePoints.size(); c++) {
		glPointSize(8.f);
		// Bind the VAO m_vaoLeftOffsetCurve and render it
		glBindVertexArray(m_vaoPipeVector[c]);
		glDrawArrays(GL_POINTS, 0, m_pipeCurvePoints[c].size());
		//glDrawArrays(GL_LINE_LOOP, 0, m_centrelinePoints.size());

		glBindVertexArray(m_vaoLeftPipeVector[c]);
		glDrawArrays(GL_POINTS, 0, m_pipeCurvePoints[c].size());
		//glDrawArrays(GL_LINE_LOOP, 0, m_centrelinePoints.size());

		glBindVertexArray(m_vaoRightPipeVector[c]);
		glDrawArrays(GL_POINTS, 0, m_pipeCurvePoints[c].size());
		//glDrawArrays(GL_LINE_LOOP, 0, m_centrelinePoints.size());
	}
}

void CCatmullRomFirstTrack::RenderPipeSurface() {
	glBindVertexArray(m_vaoPipeSurface);
	m_pipeTexture.Bind();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_pipeVertexCount);

	glBindVertexArray(m_vaoRightPipeSurface);
	m_pipeRightLeftTexture.Bind();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_rightPipeVertexCount);

	glBindVertexArray(m_vaoLeftPipeSurface);
	m_pipeRightLeftTexture.Bind();
	glDrawArrays(GL_TRIANGLE_STRIP, 0, m_leftPipeVertexCount);
}

int CCatmullRomFirstTrack::CurrentLap(float d)
{

	return (int)(d / m_distances.back());

}

void CCatmullRomFirstTrack::Release()
{
	m_texture.Release();
	m_pipeRightLeftTexture.Release();
	glDeleteVertexArrays(1, &m_vaoTrack);
	glDeleteVertexArrays(1, &m_vaoLeftOffsetCurve);
	glDeleteVertexArrays(1, &m_vaoRightOffsetCurve);
	glDeleteVertexArrays(1, &m_vaoCentreline);
	glDeleteVertexArrays(1, &m_vaoLeftPipeSurface);
	glDeleteVertexArrays(1, &m_vaoRightPipeSurface);
	glDeleteVertexArrays(1, &m_vaoPipeSurface);
	m_vboROC.Release();
	m_vboLOC.Release();
	m_vboCL.Release();
	m_vboT.Release();
	m_vboPipeSurface.Release();
	m_vboRightPipeSurface.Release();
	m_vboLeftPipeSurface.Release();



	for (int i = 0; i < m_vaoPipeVector.size(); i++) {
		glDeleteVertexArrays(1, &m_vaoPipeVector[i]);
	}

	for (int i = 0; i < m_vboPipeVector.size(); i++) {
		m_vboPipeVector[i].Release();
	}
}

glm::vec3 CCatmullRomFirstTrack::_dummy_vector(0.0f, 0.0f, 0.0f);