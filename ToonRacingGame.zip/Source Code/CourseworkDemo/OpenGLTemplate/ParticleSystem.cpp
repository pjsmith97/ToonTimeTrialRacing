#include "ParticleSystem.h"

CParticleSystem::CParticleSystem()
{}
CParticleSystem::~CParticleSystem()
{
	Release();
}
void CParticleSystem::Create(int num_particles, string filename)
{
	m_texture.Load(filename);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_S, GL_REPEAT);
	m_texture.SetSamplerObjectParameter(GL_TEXTURE_WRAP_T, GL_REPEAT);
	glGenVertexArrays(1, &m_vao);
	glBindVertexArray(m_vao);
	m_vbo.Create();
	m_vbo.Bind();

	glm::vec3 v = glm::vec3(0.f);

	m_numParticles = num_particles;

	float velocity, theta, phi;
	GLfloat* data = new GLfloat[num_particles * 3];

	for (unsigned int i = 0; i < num_particles; i++) {
		// Pick the direction of the velocity
		theta = glm::mix(0.f, (float)M_PI / 6.f, (float)(rand() % 1000) / 1000.f);
		phi = glm::mix(0.f, 2.f * (float)M_PI, (float)(rand() % 1000) / 1000.f);

		v.x = sinf(theta) * cosf(phi);
		v.y = cosf(theta);
		v.z = sinf(theta) * sinf(phi);

		velocity = glm::mix(5.25f, 5.5f, (float)(rand() % 1000) / 1000.f);

		v = v * velocity;

		data[3 * i] = v.x;
		data[3 * i + 1] = v.y;
		data[3 * i + 2] = v.z;
	}

	float* dataST = new GLfloat[num_particles];
	float time = 0.f;
	float rate = 0.00075f;

	for (unsigned int i = 0; i < num_particles; i++) {
		dataST[i] = time;
		time += rate;
	}
	m_vbo.AddData(data, num_particles * 3 * sizeof(float));
	m_vbo.AddData(dataST, num_particles * sizeof(float));
	//glBufferSubData(GL_ARRAY_BUFFER, 0, , data);
	//glBufferSubData(GL_ARRAY_BUFFER, num_particles * 3 * sizeof(float), num_particles * sizeof(float), dataST);
	

	// Upload data to GPU
	m_vbo.UploadDataToGPU(GL_STATIC_DRAW);
	//GLsizei stride = 3 * sizeof(GLfloat);

	// Vertex positions
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, 0, (void*)(num_particles * 3 * sizeof(float)));
}
void CParticleSystem::Render()
{
	glBindVertexArray(m_vao);
	m_texture.Bind();
	// Call glDrawArrays to render each side
	glPointSize(20.f);
	glDrawArrays(GL_POINTS, 0, m_numParticles);

}
void CParticleSystem::Release()
{
	m_texture.Release();
	glDeleteVertexArrays(1, &m_vao);
	m_vbo.Release();
}