#pragma once

#include "Common.h"
#include "Texture.h"
#include "VertexBufferObject.h"

// Class for generating a unit sphere
class CParticleSystem
{
public:
	CParticleSystem();
	~CParticleSystem();
	void Create(int num_particles, string filename);
	void Render();
	void Release();
private:
	int m_numParticles;
	GLuint m_vao;
	CVertexBufferObject m_vbo;
	CTexture m_texture;
};