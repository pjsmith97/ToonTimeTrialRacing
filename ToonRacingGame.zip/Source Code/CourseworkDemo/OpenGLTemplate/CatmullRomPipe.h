#pragma once
#include "Common.h"
#include "vertexBufferObject.h"
#include "vertexBufferObjectIndexed.h"
#include "Texture.h"


class CCatmullRomPipe
{
public:
	CCatmullRomPipe();
	~CCatmullRomPipe();

	void CreateCentreline();
	void RenderCentreline();

	void CreatePipePoints();
	void RenderPipePoints();

	void RenderPipeSurface();

	bool Sample(float d, glm::vec3& p, glm::vec3& up = _dummy_vector); // Return a point on the centreline based on a certain distance along the control curve.

	glm::vec3 Interpolate(glm::vec3& p0, glm::vec3& p1, glm::vec3& p2, glm::vec3& p3, float t);

	void Release();

	void CreatePipeSurface(string filename);

	std::vector<glm::vec3> buildCircle(float radius, int steps);


private:

	void SetControlPoints();
	void ComputeLengthsAlongControlPoints();
	void UniformlySampleControlPoints(int numSamples);
	void FindPipePoints(glm::vec3 eyeB, vector<glm::vec3> circle, glm::vec3 eyeN, float trackDistance);


	vector<float> m_distances;
	CTexture m_pipeTexture;
	vector<glm::vec3> m_centrelinePoints;	// Centreline points
	GLuint m_vaoCentreline;

	vector<GLuint> m_vaoPipeVector;

	GLuint m_vaoPipeSurface;

	CVertexBufferObject m_vboCL;

	vector <CVertexBufferObject> m_vboPipeVector;

	CVertexBufferObject m_vboPipeSurface;

	static glm::vec3 _dummy_vector;
	vector<glm::vec3> m_controlPoints;		// Control points, which are interpolated to produce the centreline points
	vector<glm::vec3> m_controlUpVectors;	// Control upvectors, which are interpolated to produce the centreline upvectors

	vector<glm::vec3> m_centrelineUpVectors;// Centreline upvectors

	vector<vector<glm::vec3>> m_pipeCurvePoints;

	vector<vector<glm::vec3>> m_pipeCurveNormals;

	unsigned int m_vertexCount;				// Number of vertices in the track VBO
	unsigned int m_pipeVertexCount;

	int num_ctrl_pts = 250;

	float width = 10.f;
};
