#pragma once
#include "Common.h"
#include "vertexBufferObject.h"
#include "vertexBufferObjectIndexed.h"
#include "Texture.h"


class CCatmullRomFirstTrack
{
public:
	CCatmullRomFirstTrack();
	~CCatmullRomFirstTrack();

	void CreateCentreline();
	void RenderCentreline();

	void CreateOffsetCurves();
	void RenderOffsetCurves();

	void CreateTrack(string filename);
	void RenderTrack();

	void CreatePipePoints();
	void RenderPipePoints();

	void CreateRightLeftPipeSurface(string filename);
	void RenderPipeSurface();

	int CurrentLap(float d); // Return the currvent lap (starting from 0) based on distance along the control curve.

	bool Sample(float d, glm::vec3& p, glm::vec3& up = _dummy_vector); // Return a point on the centreline based on a certain distance along the control curve.

	glm::vec3 Interpolate(glm::vec3& p0, glm::vec3& p1, glm::vec3& p2, glm::vec3& p3, float t);

	void Release();

	void CreateBasePipeSurface(string filename);

	std::vector<glm::vec3> buildCircle(float radius, int steps, int type);


private:

	void SetControlPoints();
	void ComputeLengthsAlongControlPoints();
	void UniformlySampleControlPoints(int numSamples);
	void FindPipePoints(glm::vec3 eyeB, vector<glm::vec3> circle, vector<glm::vec3> circle2, glm::vec3 eyeN,
		float trackDistance);


	vector<float> m_distances;
	CTexture m_texture;
	CTexture m_pipeRightLeftTexture;
	CTexture m_pipeTexture;
	vector<glm::vec3> m_centrelinePoints;	// Centreline points
	vector<glm::vec3> m_leftCentreLinePoints; // Centreline for left pipe
	vector<glm::vec3> m_rightCentreLinePoints; //Centreline for right pipe
	GLuint m_vaoCentreline;
	GLuint m_vaoLeftOffsetCurve;
	GLuint m_vaoRightOffsetCurve;
	GLuint m_vaoTrack;

	vector<GLuint> m_vaoPipeVector;
	vector<GLuint> m_vaoLeftPipeVector;
	vector<GLuint> m_vaoRightPipeVector;

	GLuint m_vaoPipeSurface;
	GLuint m_vaoLeftPipeSurface;
	GLuint m_vaoRightPipeSurface;

	CVertexBufferObject m_vboCL;
	CVertexBufferObject m_vboLOC;
	CVertexBufferObject m_vboROC;
	CVertexBufferObject m_vboT;

	vector <CVertexBufferObject> m_vboPipeVector;
	vector <CVertexBufferObject> m_vboLeftPipeVector;
	vector <CVertexBufferObject> m_vboRightPipeVector;

	CVertexBufferObject m_vboPipeSurface;
	CVertexBufferObject m_vboLeftPipeSurface;
	CVertexBufferObject m_vboRightPipeSurface;

	static glm::vec3 _dummy_vector;
	vector<glm::vec3> m_controlPoints;		// Control points, which are interpolated to produce the centreline points
	vector<glm::vec3> m_controlUpVectors;	// Control upvectors, which are interpolated to produce the centreline upvectors

	vector<glm::vec3> m_centrelineUpVectors;// Centreline upvectors

	vector<glm::vec3> m_leftOffsetPoints;	// Left offset curve points
	vector<glm::vec3> m_rightOffsetPoints;	// Right offset curve points

	vector<vector<glm::vec3>> m_pipeCurvePoints;
	vector<vector<glm::vec3>> m_rightPipeCurvePoints;
	vector<vector<glm::vec3>> m_leftPipeCurvePoints;

	vector<vector<glm::vec3>> m_pipeCurveNormals;
	vector<vector<glm::vec3>> m_rightPipeCurveNormals;
	vector<vector<glm::vec3>> m_leftPipeCurveNormals;


	unsigned int m_vertexCount;				// Number of vertices in the track VBO
	unsigned int m_pipeVertexCount;
	unsigned int m_rightPipeVertexCount;
	unsigned int m_leftPipeVertexCount;

	int num_ctrl_pts = 500;

	float width = 10.f;
};
#pragma once
